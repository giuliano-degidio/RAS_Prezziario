--
-- PostgreSQL database dump
--

\restrict XXaPjGenISI46sq0eEtFEvmQ2YRky78goHBmCSdcoGv0ON0udcpdwkxhpDaqdTv

-- Dumped from database version 17.0
-- Dumped by pg_dump version 17.6

-- Started on 2026-11-05 22:58:55

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 12 (class 2615 OID 395990660)
-- Name: hcbi_utility; Type: SCHEMA; Schema: -; Owner: hcbi_utility
--

CREATE SCHEMA hcbi_utility;


ALTER SCHEMA hcbi_utility OWNER TO hcbi_utility;

--
-- TOC entry 694 (class 1255 OID 395991033)
-- Name: disconnect_dblink_logging(); Type: FUNCTION; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE FUNCTION hcbi_utility.disconnect_dblink_logging() RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $$
		DECLARE
			v_connections text[];
		BEGIN
			v_connections :=
				hcbi_utility.dblink_get_connections();

			IF v_connections IS NOT NULL
			   AND 'LOG_DBLINK' = ANY(v_connections)
			THEN
				PERFORM hcbi_utility.dblink_disconnect('LOG_DBLINK');
				RETURN true;
			END IF;

			RETURN false;
		END;
		$$;


ALTER FUNCTION hcbi_utility.disconnect_dblink_logging() OWNER TO hcbi_utility;

--
-- TOC entry 633 (class 1255 OID 395991034)
-- Name: ensure_dblink_logging(); Type: FUNCTION; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE FUNCTION hcbi_utility.ensure_dblink_logging() RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $$
DECLARE
    v_connections text[];
    v_health       integer;
    v_sqlstate     text;
    v_sqlerrm      text;
    v_sql_detail   text;
    v_sql_hint     text;
    v_sql_context  text;
    v_error_detail text;
BEGIN
    v_connections := hcbi_utility.dblink_get_connections();

    IF v_connections IS NULL
       OR NOT ('LOG_DBLINK' = ANY(v_connections))
    THEN
        PERFORM hcbi_utility.dblink_connect(
            'LOG_DBLINK',
            hcbi_utility.get_conn_string()
        );
    ELSE
        -- A registered connection may no longer be usable.
        -- Verify it with a minimal query and reconnect once if necessary.
        BEGIN
            SELECT t.health
              INTO STRICT v_health
              FROM hcbi_utility.dblink(
                       'LOG_DBLINK',
                       'SELECT 1::integer'
                   ) AS t(health integer);

            IF v_health IS DISTINCT FROM 1 THEN
                RAISE EXCEPTION
                    USING
                        ERRCODE = 'P0001',
                        MESSAGE = 'Verifica LOG_DBLINK non valida',
                        DETAIL = format(
                            'La query di health check ha restituito il valore %s.',
                            coalesce(v_health::text, 'NULL')
                        );
            END IF;
        EXCEPTION
            WHEN OTHERS THEN
                -- Best effort: remove the unusable named connection.
                BEGIN
                    PERFORM hcbi_utility.dblink_disconnect('LOG_DBLINK');
                EXCEPTION
                    WHEN OTHERS THEN
                        NULL;
                END;

                PERFORM hcbi_utility.dblink_connect(
                    'LOG_DBLINK',
                    hcbi_utility.get_conn_string()
                );

                -- Verify the newly opened connection before returning success.
                SELECT t.health
                  INTO STRICT v_health
                  FROM hcbi_utility.dblink(
                           'LOG_DBLINK',
                           'SELECT 1::integer'
                       ) AS t(health integer);

                IF v_health IS DISTINCT FROM 1 THEN
                    RAISE EXCEPTION
                        USING
                            ERRCODE = 'P0001',
                            MESSAGE = 'Riconnessione LOG_DBLINK non valida',
                            DETAIL = format(
                                'La query di health check ha restituito il valore %s.',
                                coalesce(v_health::text, 'NULL')
                            );
                END IF;
        END;
    END IF;

EXCEPTION
    WHEN duplicate_object THEN
        -- Ignore the duplicate only if the expected connection now exists.
        v_connections := hcbi_utility.dblink_get_connections();

        IF v_connections IS NULL
           OR NOT ('LOG_DBLINK' = ANY(v_connections))
        THEN
            RAISE;
        END IF;

    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            v_sqlstate    = RETURNED_SQLSTATE,
            v_sqlerrm     = MESSAGE_TEXT,
            v_sql_detail  = PG_EXCEPTION_DETAIL,
            v_sql_hint    = PG_EXCEPTION_HINT,
            v_sql_context = PG_EXCEPTION_CONTEXT;

        v_error_detail := left(
            concat_ws(
                E'\n',
                CASE
                    WHEN nullif(v_sql_detail, '') IS NOT NULL
                        THEN 'DETAIL=' || left(v_sql_detail, 1000)
                END,
                CASE
                    WHEN nullif(v_sql_hint, '') IS NOT NULL
                        THEN 'HINT=' || left(v_sql_hint, 500)
                END,
                CASE
                    WHEN nullif(v_sql_context, '') IS NOT NULL
                        THEN 'CONTEXT=' || left(v_sql_context, 1200)
                END
            ),
            3000
        );

        RAISE EXCEPTION
            USING
                ERRCODE = coalesce(nullif(v_sqlstate, ''), 'P0001'),
                MESSAGE = left(
                    'Errore inizializzazione LOG_DBLINK: '
                    || coalesce(v_sqlerrm, 'errore PostgreSQL non specificato'),
                    2000
                ),
                DETAIL = coalesce(
                    nullif(v_error_detail, ''),
                    'Nessun dettaglio aggiuntivo disponibile.'
                );
END;
$$;


ALTER FUNCTION hcbi_utility.ensure_dblink_logging() OWNER TO hcbi_utility;

--
-- TOC entry 5538 (class 0 OID 0)
-- Dependencies: 633
-- Name: FUNCTION ensure_dblink_logging(); Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON FUNCTION hcbi_utility.ensure_dblink_logging() IS 'Garantisce la disponibilita della connessione persistente LOG_DBLINK; verifica la connessione esistente, tenta una riconnessione controllata e preserva la diagnostica PostgreSQL.';


--
-- TOC entry 521 (class 1255 OID 398901528)
-- Name: fn_dwh_schedule_enable_exclusive(); Type: FUNCTION; Schema: hcbi_utility; Owner: postgres
--

CREATE FUNCTION hcbi_utility.fn_dwh_schedule_enable_exclusive() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.enabled AND (TG_OP = 'INSERT' OR OLD.enabled IS DISTINCT FROM NEW.enabled) THEN
        UPDATE hcbi_utility.dwh_schedule
           SET enabled = false,
               updated_at = clock_timestamp()
         WHERE enabled = true
           AND schedule_id IS DISTINCT FROM NEW.schedule_id;
    END IF;
    NEW.updated_at := clock_timestamp();
    RETURN NEW;
END;
$$;


ALTER FUNCTION hcbi_utility.fn_dwh_schedule_enable_exclusive() OWNER TO postgres;

--
-- TOC entry 486 (class 1255 OID 395991035)
-- Name: get_conn_string(character varying); Type: FUNCTION; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE FUNCTION hcbi_utility.get_conn_string(p_conn_name character varying DEFAULT 'LOOPBACK_DBLINK'::character varying) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_conn_string TEXT;
BEGIN

    SELECT conn_string
    INTO v_conn_string
    FROM hcbi_utility.cfg_connections
    WHERE UPPER(conn_name) = UPPER(p_conn_name);

    IF v_conn_string IS NULL THEN
        RAISE EXCEPTION
            'Connessione "%" non trovata nella tabella hcbi_utility.cfg_connections',
            p_conn_name;
    END IF;

    RETURN v_conn_string;

END;
$$;


ALTER FUNCTION hcbi_utility.get_conn_string(p_conn_name character varying) OWNER TO hcbi_utility;

--
-- TOC entry 771 (class 1255 OID 396134665)
-- Name: get_current_etl_execution_uuid(); Type: FUNCTION; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE FUNCTION hcbi_utility.get_current_etl_execution_uuid() RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $_$
DECLARE
    c_zero_uuid constant uuid := '00000000-0000-0000-0000-000000000000'::uuid;
    v_execution_uuid uuid := c_zero_uuid;
    v_run_table regclass;
    v_structure_valid boolean := false;
BEGIN
    ----------------------------------------------------------------------
    -- Verifica l'esistenza della tabella delle esecuzioni DWH.
    ----------------------------------------------------------------------
    v_run_table := to_regclass('hcbi_utility.etl_dwh_refresh_run');

    IF v_run_table IS NULL THEN
        RAISE WARNING
            'Tabella hcbi_utility.etl_dwh_refresh_run non trovata: restituito UUID zero';
        RETURN c_zero_uuid;
    END IF;

    ----------------------------------------------------------------------
    -- Verifica le colonne necessarie e i relativi tipi.
    ----------------------------------------------------------------------
    SELECT count(*) = 4
      INTO v_structure_valid
      FROM pg_catalog.pg_attribute a
     WHERE a.attrelid = v_run_table
       AND a.attnum > 0
       AND NOT a.attisdropped
       AND (
            (a.attname = 'run_id'
             AND a.atttypid = 'pg_catalog.int8'::regtype)
         OR (a.attname = 'execution_uuid'
             AND a.atttypid = 'pg_catalog.uuid'::regtype)
         OR (a.attname = 'ended_at'
             AND a.atttypid = 'pg_catalog.timestamptz'::regtype)
         OR (a.attname = 'status'
             AND a.atttypid IN (
                 'pg_catalog.varchar'::regtype,
                 'pg_catalog.text'::regtype,
                 'pg_catalog.bpchar'::regtype
             ))
       );

    IF NOT v_structure_valid THEN
        RAISE WARNING
            'Struttura di hcbi_utility.etl_dwh_refresh_run non valida: restituito UUID zero';
        RETURN c_zero_uuid;
    END IF;

    ----------------------------------------------------------------------
    -- Recupera l'UUID dell'ultima esecuzione DWH ancora RUNNING.
    ----------------------------------------------------------------------
    EXECUTE
        'SELECT execution_uuid
           FROM hcbi_utility.etl_dwh_refresh_run
          WHERE ended_at IS NULL
            AND status = $1
          ORDER BY run_id DESC
          LIMIT 1'
       INTO v_execution_uuid
      USING 'RUNNING';

    RETURN COALESCE(v_execution_uuid, c_zero_uuid);

EXCEPTION
    ----------------------------------------------------------------------
    -- La funzione e' non bloccante: qualsiasi errore restituisce UUID zero.
    ----------------------------------------------------------------------
    WHEN OTHERS THEN
        RAISE WARNING
            'Errore nel recupero dell''execution_uuid DWH. SQLSTATE=%, SQLERRM=%. Restituito UUID zero',
            SQLSTATE,
            SQLERRM;
        RETURN c_zero_uuid;
END;
$_$;


ALTER FUNCTION hcbi_utility.get_current_etl_execution_uuid() OWNER TO hcbi_utility;

--
-- TOC entry 5542 (class 0 OID 0)
-- Dependencies: 771
-- Name: FUNCTION get_current_etl_execution_uuid(); Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON FUNCTION hcbi_utility.get_current_etl_execution_uuid() IS 'Restituisce execution_uuid dell''ultima esecuzione DWH RUNNING; restituisce UUID zero se non disponibile o in caso di errore.';


--
-- TOC entry 561 (class 1255 OID 395991036)
-- Name: init_dblink_logging(); Type: PROCEDURE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE PROCEDURE hcbi_utility.init_dblink_logging()
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $$
		BEGIN
			PERFORM hcbi_utility.ensure_dblink_logging();
		END;
		$$;


ALTER PROCEDURE hcbi_utility.init_dblink_logging() OWNER TO hcbi_utility;

--
-- TOC entry 665 (class 1255 OID 395991037)
-- Name: pkg_log_display_backtrace_fnc(text); Type: FUNCTION; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE FUNCTION hcbi_utility.pkg_log_display_backtrace_fnc(p_context text DEFAULT NULL::text) RETURNS text
    LANGUAGE plpgsql
    AS $$
	BEGIN
		RETURN
			  '***** Backtrace Start *****'
		   || E'\n'
		   || coalesce(p_context,'Nessun contesto disponibile')
		   || E'\n'
		   || '***** Backtrace End *****';
	END;
	$$;


ALTER FUNCTION hcbi_utility.pkg_log_display_backtrace_fnc(p_context text) OWNER TO hcbi_utility;

--
-- TOC entry 522 (class 1255 OID 395991038)
-- Name: pkg_log_display_error_stack_fnc(text, text, text, text); Type: FUNCTION; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE FUNCTION hcbi_utility.pkg_log_display_error_stack_fnc(p_sqlstate text DEFAULT NULL::text, p_message text DEFAULT NULL::text, p_detail text DEFAULT NULL::text, p_hint text DEFAULT NULL::text) RETURNS text
    LANGUAGE plpgsql
    AS $$
	DECLARE
		v_result text;
	BEGIN
		v_result :=
			  '***** Error Stack Start *****' || E'\n'
		   || 'SQLSTATE : ' || coalesce(p_sqlstate,'') || E'\n'
		   || 'MESSAGE  : ' || coalesce(p_message,'') || E'\n';

		IF p_detail IS NOT NULL THEN
			v_result :=
				v_result ||
				'DETAIL   : ' || p_detail || E'\n';
		END IF;

		IF p_hint IS NOT NULL THEN
			v_result :=
				v_result ||
				'HINT     : ' || p_hint || E'\n';
		END IF;

		v_result :=
			v_result ||
			'***** Error Stack End *****';

		RETURN v_result;
	END;
	$$;


ALTER FUNCTION hcbi_utility.pkg_log_display_error_stack_fnc(p_sqlstate text, p_message text, p_detail text, p_hint text) OWNER TO hcbi_utility;

--
-- TOC entry 707 (class 1255 OID 395991039)
-- Name: pkg_log_fnc_insert_log(bigint, bigint, bigint, text, timestamp without time zone, timestamp without time zone, text); Type: FUNCTION; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE FUNCTION hcbi_utility.pkg_log_fnc_insert_log(p_id_chain_log bigint, p_id_chain bigint, p_id_step bigint, p_ds_step_name text, p_dt_start timestamp without time zone DEFAULT clock_timestamp(), p_dt_creation timestamp without time zone DEFAULT clock_timestamp(), p_ds_transaction text DEFAULT CURRENT_USER) RETURNS bigint
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $_$
	DECLARE
		v_sql     text;
		v_id_log  bigint;
	BEGIN
		IF p_id_chain_log IS NULL THEN
			RAISE EXCEPTION
				'PKG_LOG_FNC_INSERT_LOG: p_id_chain_log obbligatorio';
		END IF;

		IF p_id_chain IS NULL THEN
			RAISE EXCEPTION
				'PKG_LOG_FNC_INSERT_LOG: p_id_chain obbligatorio';
		END IF;

		IF p_id_step IS NULL THEN
			RAISE EXCEPTION
				'PKG_LOG_FNC_INSERT_LOG: p_id_step obbligatorio';
		END IF;

		PERFORM hcbi_utility.ensure_dblink_logging();

		/*
		 * format() con %L gestisce:
		 *
		 * - apici nei testi;
		 * - valori NULL;
		 * - conversione sicura in letterali SQL.
		 */
		v_sql := format(
			$sql$
			INSERT INTO hcbi_utility.log_step
			(
				id_chain_log,
				id_chain,
				id_step,
				ds_step_name,
				dt_start,
				dt_creation,
				tx_creation_by
			)
			VALUES
			(
				%L::bigint,
				%L::bigint,
				%L::bigint,
				%L::text,
				%L::timestamp,
				%L::timestamp,
				%L::text
			)
			RETURNING id_log
			$sql$,
			p_id_chain_log,
			p_id_chain,
			p_id_step,
			p_ds_step_name,
			p_dt_start,
			p_dt_creation,
			p_ds_transaction
		);
--RAISE NOTICE 'SQL=%', v_sql;
		/*
		 * Si usa dblink() anziché dblink_exec() perché è
		 * necessario recuperare ID_LOG dalla clausola RETURNING.
		 */	 
		SELECT risultato.id_log
		  INTO STRICT v_id_log
		  FROM hcbi_utility.dblink(
				   'LOG_DBLINK',
				   v_sql
			   ) AS risultato(id_log bigint);

		RETURN v_id_log;
	EXCEPTION
		WHEN OTHERS THEN
			RAISE EXCEPTION
				'PKG_LOG_FNC_INSERT_LOG: errore inserimento LOG_STEP. '
				'SQLSTATE: %, errore: %',
				SQLSTATE,
				SQLERRM;
	END;
	
$_$;


ALTER FUNCTION hcbi_utility.pkg_log_fnc_insert_log(p_id_chain_log bigint, p_id_chain bigint, p_id_step bigint, p_ds_step_name text, p_dt_start timestamp without time zone, p_dt_creation timestamp without time zone, p_ds_transaction text) OWNER TO hcbi_utility;

--
-- TOC entry 505 (class 1255 OID 395991040)
-- Name: pkg_log_prc_error_update_log(bigint, text, text, timestamp without time zone, text); Type: PROCEDURE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE PROCEDURE hcbi_utility.pkg_log_prc_error_update_log(IN p_id_log bigint, IN p_ds_status text, IN p_ds_error text, IN p_dt_update timestamp without time zone DEFAULT clock_timestamp(), IN p_ds_transaction text DEFAULT CURRENT_USER)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $_$
DECLARE
    v_sql          text;
    v_exec_result  text;
    v_error_message text;

    v_sqlstate text;
    v_sqlerrm  text;
BEGIN
    IF p_id_log IS NULL THEN
        RAISE EXCEPTION
            'PKG_LOG_PRC_ERROR_UPDATE_LOG: p_id_log obbligatorio';
    END IF;

    /*
     * Il messaggio viene già costruito dalla procedura chiamante.
     * Non vengono richiamate funzioni aggiuntive di formattazione
     * dello stack, evitando che un loro errore mascheri l'errore originale.
     */
    v_error_message :=
        COALESCE(
            p_ds_error,
            'Errore PostgreSQL non specificato'
        );

    PERFORM hcbi_utility.ensure_dblink_logging();

    v_sql := format(
        $sql$
        UPDATE hcbi_utility.log_step
           SET dt_end           = clock_timestamp(),
               tx_error_message = %L::text,
               ds_status        = %L::text,
               dt_update        = %L::timestamp,
               tx_update_by     = %L::text
         WHERE id_log = %L::bigint
        $sql$,
        v_error_message,
        p_ds_status,
        p_dt_update,
        p_ds_transaction,
        p_id_log
    );

    v_exec_result :=
        hcbi_utility.dblink_exec(
            'LOG_DBLINK',
            v_sql
        );

    IF v_exec_result = 'UPDATE 0' THEN
        RAISE EXCEPTION
            'PKG_LOG_PRC_ERROR_UPDATE_LOG: nessuna riga LOG_STEP trovata per ID_LOG=%',
            p_id_log;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        /*
         * SQLSTATE e SQLERRM vengono utilizzati soltanto
         * all'interno del blocco EXCEPTION.
         */
        v_sqlstate := SQLSTATE;
        v_sqlerrm  := SQLERRM;

        RAISE EXCEPTION
            'PKG_LOG_PRC_ERROR_UPDATE_LOG: errore aggiornamento LOG_STEP ID_LOG=%. SQLSTATE: %, errore: %',
            p_id_log,
            v_sqlstate,
            v_sqlerrm;
END;
$_$;


ALTER PROCEDURE hcbi_utility.pkg_log_prc_error_update_log(IN p_id_log bigint, IN p_ds_status text, IN p_ds_error text, IN p_dt_update timestamp without time zone, IN p_ds_transaction text) OWNER TO hcbi_utility;

--
-- TOC entry 573 (class 1255 OID 395991041)
-- Name: pkg_log_prc_update_log(bigint, bigint, bigint, bigint, bigint, bigint, text, timestamp without time zone, text); Type: PROCEDURE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE PROCEDURE hcbi_utility.pkg_log_prc_update_log(IN p_id_log bigint, IN p_nr_selected bigint DEFAULT NULL::bigint, IN p_nr_inserted bigint DEFAULT NULL::bigint, IN p_nr_updated bigint DEFAULT NULL::bigint, IN p_nr_deleted bigint DEFAULT NULL::bigint, IN p_nr_rec_errors bigint DEFAULT NULL::bigint, IN p_ds_status text DEFAULT NULL::text, IN p_dt_update timestamp without time zone DEFAULT clock_timestamp(), IN p_ds_transaction text DEFAULT CURRENT_USER)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $_$
DECLARE
    v_sql           text;
    v_exec_result   text;
BEGIN
    IF p_id_log IS NULL THEN
        RAISE EXCEPTION
            'PKG_LOG_PRC_UPDATE_LOG: p_id_log obbligatorio';
    END IF;

    PERFORM hcbi_utility.ensure_dblink_logging();

    v_sql := format(
        $sql$
        UPDATE hcbi_utility.log_step
           SET dt_end          = clock_timestamp(),
               nr_rec_selected = %L::bigint,
               nr_rec_inserted = %L::bigint,
               nr_rec_updated  = %L::bigint,
               nr_rec_deleted  = %L::bigint,
               nr_rec_errors   = %L::bigint,
               ds_status       = %L::text,
               dt_update       = %L::timestamp,
               tx_update_by    = %L::text
         WHERE id_log = %L::bigint
        $sql$,
        p_nr_selected,
        p_nr_inserted,
        p_nr_updated,
        p_nr_deleted,
        p_nr_rec_errors,
        p_ds_status,
        p_dt_update,
        p_ds_transaction,
        p_id_log
    );

    v_exec_result :=
        hcbi_utility.dblink_exec(
            'LOG_DBLINK',
            v_sql
        );

    IF v_exec_result = 'UPDATE 0' THEN
        RAISE EXCEPTION
            'PKG_LOG_PRC_UPDATE_LOG: nessuna riga LOG_STEP '
            'trovata per ID_LOG=%',
            p_id_log;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION
            'PKG_LOG_PRC_UPDATE_LOG: errore aggiornamento '
            'LOG_STEP ID_LOG=%. SQLSTATE: %, errore: %',
            p_id_log,
            SQLSTATE,
            SQLERRM;
END;
$_$;


ALTER PROCEDURE hcbi_utility.pkg_log_prc_update_log(IN p_id_log bigint, IN p_nr_selected bigint, IN p_nr_inserted bigint, IN p_nr_updated bigint, IN p_nr_deleted bigint, IN p_nr_rec_errors bigint, IN p_ds_status text, IN p_dt_update timestamp without time zone, IN p_ds_transaction text) OWNER TO hcbi_utility;

--
-- TOC entry 735 (class 1255 OID 395991042)
-- Name: prc_end_chain(bigint, text, text); Type: PROCEDURE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE PROCEDURE hcbi_utility.prc_end_chain(IN p_id_log bigint, IN p_ds_status text, IN p_error_msg text DEFAULT NULL::text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $_$
DECLARE
    v_sql          text;
    v_exec_result  text;
BEGIN
    IF p_id_log IS NULL THEN
        RAISE EXCEPTION
            'PRC_END_CHAIN: p_id_log obbligatorio';
    END IF;

    PERFORM hcbi_utility.ensure_dblink_logging();

    v_sql := format(
        $sql$
        UPDATE hcbi_utility.log_chain
           SET dt_end           = clock_timestamp(),
               ds_status        = %L::text,
               tx_error_message = %L::text
         WHERE id_log = %L::bigint
        $sql$,
        p_ds_status,
        p_error_msg,
        p_id_log
    );

    v_exec_result :=
        hcbi_utility.dblink_exec(
            'LOG_DBLINK',
            v_sql
        );

    IF v_exec_result = 'UPDATE 0' THEN
        RAISE EXCEPTION
            'PRC_END_CHAIN: nessuna riga LOG_CHAIN trovata '
            'per ID_LOG=%',
            p_id_log;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION
            'PRC_END_CHAIN: errore chiusura LOG_CHAIN '
            'ID_LOG=%. SQLSTATE: %, errore: %',
            p_id_log,
            SQLSTATE,
            SQLERRM;
END;
$_$;


ALTER PROCEDURE hcbi_utility.prc_end_chain(IN p_id_log bigint, IN p_ds_status text, IN p_error_msg text) OWNER TO hcbi_utility;

--
-- TOC entry 575 (class 1255 OID 395991043)
-- Name: prc_execute_chain(bigint); Type: PROCEDURE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE PROCEDURE hcbi_utility.prc_execute_chain(IN p_id_chain bigint)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $_$

DECLARE
    r_step                       record;
    r_stale_log                  record;

    v_id_log                     bigint;
    v_step_log_id                bigint;
    v_ds_step_name               text;
    v_ds_dependency_status       text;
    v_result                     integer;

    v_schema_name                text;
    v_package_name               text;
    v_procedure_name             text;
    v_procedure_phase            text;

    v_sql                        text;
    v_error_message              text;
    v_chain_error_message        text;
    v_error_detail               text;
    v_error_hint                 text;
    v_error_context              text;
    v_sqlstate                   text;

    v_chain_exists               boolean;
    v_non_blocking_error         boolean := false;
    v_blocking_error             boolean := false;

    v_procedure_phases           text[] := ARRAY[
        'prc_initialize',
        'prc_main',
        'prc_finalize'
    ];
BEGIN
    ----------------------------------------------------------------------
    -- Validazione del parametro
    ----------------------------------------------------------------------
    IF p_id_chain IS NULL THEN
        RAISE EXCEPTION
            USING
                ERRCODE = '22004',
                MESSAGE = 'Il parametro p_id_chain non può essere NULL';
    END IF;

    ----------------------------------------------------------------------
    -- Verifica dell'esistenza e dell'attivazione della catena
    ----------------------------------------------------------------------
    SELECT EXISTS
           (
               SELECT 1
               FROM hcbi_utility.srv_config_chain c
               WHERE c.id_chain = p_id_chain
                 AND c.fl_active = 'Y'
           )
      INTO v_chain_exists;

    IF NOT v_chain_exists THEN
        RAISE EXCEPTION
            USING
                ERRCODE = 'P0001',
                MESSAGE = format(
                    'La catena %s non esiste oppure non è attiva',
                    p_id_chain
                );
    END IF;

    ----------------------------------------------------------------------
    -- Lock applicativo sulla catena
    --
    -- Impedisce che due sessioni eseguano contemporaneamente
    -- la stessa catena.
    ----------------------------------------------------------------------
    IF NOT pg_try_advisory_xact_lock(
        hashtext('hcbi_utility.prc_execute_chain')::integer,
        p_id_chain::integer
    ) THEN
        RAISE EXCEPTION
            USING
                ERRCODE = '55006',
                MESSAGE = format(
                    'La catena %s risulta già in esecuzione',
                    p_id_chain
                );
    END IF;

    ----------------------------------------------------------------------
    -- Riconciliazione di log RUNNING rimasti da esecuzioni interrotte
    ----------------------------------------------------------------------
    -- A questo punto il lock advisory transazionale e' gia' stato acquisito.
    -- Un'altra esecuzione conforme di questa procedura non puo' essere attiva
    -- per la stessa catena; pertanto le righe RUNNING precedenti sono
    -- residui di sessioni terminate prima della chiusura del log.
    --
    -- La lettura e la chiusura avvengono via LOG_DBLINK: oltre a sopravvivere
    -- al rollback principale, la riconciliazione evita che un vecchio log
    -- blocchi per sempre le esecuzioni successive.
    ----------------------------------------------------------------------
  
		BEGIN
		    PERFORM hcbi_utility.ensure_dblink_logging();
		
		EXCEPTION
		    WHEN OTHERS THEN
			v_blocking_error := true;
		        RAISE WARNING
		            'Errore inizializzazione LOG_DBLINK: SQLSTATE=% | SQLERRM=%',
		            SQLSTATE,
		            SQLERRM;

		        -- Rilancia l'eccezione originale
		        --RAISE ;
		END;



    v_sql := format(
        $sql$
        SELECT id_log
          FROM hcbi_utility.log_chain
         WHERE id_chain = %L::bigint
           AND ds_status = 'RUNNING'
         ORDER BY id_log
        $sql$,
        p_id_chain
    );

    FOR r_stale_log IN
        SELECT stale.id_log
          FROM hcbi_utility.dblink('LOG_DBLINK', v_sql)
               AS stale(id_log bigint)
    LOOP
        CALL hcbi_utility.prc_end_chain(
            r_stale_log.id_log,
            'FAILED',
            'Esecuzione precedente interrotta prima della chiusura del log; '
            'nessun lock advisory attivo al momento della riconciliazione.'
        );

        RAISE WARNING
            'Riga log RUNNING obsoleta riconciliata: catena %, id_log=%',
            p_id_chain,
            r_stale_log.id_log;
    END LOOP;

    --ATTENZIONE MODIFICARE LE SEGUENTI RIGHE DI TUNING IN BASE ALLE RISORSE DEL SERVER POSTGRES
SET LOCAL work_mem = '64MB';
SET LOCAL maintenance_work_mem ='4GB';-- '256MB';
--FINE ATTENZIONE MODIFICARE LE SEGUENTI RIGHE DI TUNING IN BASE ALLE RISORSE DEL SERVER POSTGRES

    ----------------------------------------------------------------------
    -- Apertura del log della catena nella sessione indipendente di loopback
    ----------------------------------------------------------------------
    -- prc_start_chain crea la riga attraverso LOG_DBLINK e restituisce
    -- l'identificativo generato. L'UUID viene calcolato nella sessione
    -- chiamante e passato al comando remoto; non dipende quindi dallo stato
    -- di sessione del collegamento dblink.
    ----------------------------------------------------------------------
    CALL hcbi_utility.prc_start_chain(p_id_chain, v_id_log);

    ----------------------------------------------------------------------
    -- Elaborazione degli step attivi
    ----------------------------------------------------------------------
    FOR r_step IN
        SELECT
            s.id_step,
            s.id_chain,
            s.ds_step_name,
            s.ds_package_name,
            s.nr_step_order,
            s.id_dependency_step,
            s.nr_retry_count,
            s.fl_blocking
        FROM hcbi_utility.srv_config_step s
        WHERE s.id_chain = p_id_chain
          AND s.fl_active = 'Y'
        ORDER BY
            s.nr_step_order,
            s.id_step
    LOOP
        ------------------------------------------------------------------
        -- Reset delle variabili relative allo step
        ------------------------------------------------------------------
        v_result                 := NULL;
        v_ds_dependency_status   := NULL;
        v_ds_step_name           := r_step.ds_step_name;

        ------------------------------------------------------------------
        -- Validazione della configurazione dello step
        ------------------------------------------------------------------
        IF NULLIF(btrim(r_step.ds_package_name), '') IS NULL THEN
            v_error_message := format(
                'DS_PACKAGE_NAME non valorizzato per lo step %s',
                r_step.id_step
            );

            /*
             * Registra il log dello step con la routine comune su LOG_DBLINK, quindi
             * aggiorna esito e messaggio dallo stesso canale indipendente. Anche gli
             * esiti FAILED e SKIPPED restano cosi disponibili dopo un rollback.
             */
            v_chain_error_message := v_error_message;
            v_step_log_id := hcbi_utility.pkg_log_fnc_insert_log(
                v_id_log,
                p_id_chain,
                r_step.id_step,
                COALESCE(r_step.ds_step_name, 'STEP_' || r_step.id_step),
                clock_timestamp()::timestamp,
                clock_timestamp()::timestamp,
                session_user
            );

            CALL hcbi_utility.pkg_log_prc_error_update_log(
                v_step_log_id,
                'FAILED',
                left(v_error_message, 4000),
                clock_timestamp()::timestamp,
                session_user
            );

            IF COALESCE(r_step.fl_blocking, 'Y') = 'Y' THEN
                v_blocking_error := true;
                EXIT;
            ELSE
                v_non_blocking_error := true;
                CONTINUE;
            END IF;
        END IF;

        ------------------------------------------------------------------
        -- Controllo dello stato dell'eventuale step dipendente
        ------------------------------------------------------------------
        IF r_step.id_dependency_step IS NOT NULL THEN
            SELECT ls.ds_status
              INTO v_ds_dependency_status
              FROM hcbi_utility.log_step ls
             WHERE ls.id_chain_log = v_id_log
               AND ls.id_chain = p_id_chain
               AND ls.id_step = r_step.id_dependency_step
             ORDER BY
                 ls.dt_start DESC NULLS LAST,
                 ls.dt_creation DESC NULLS LAST
             LIMIT 1;

            IF v_ds_dependency_status IS DISTINCT FROM 'SUCCESS' THEN
                v_error_message := format(
                    'Step non eseguito: dipendenza %s non completata con successo. Stato rilevato: %s',
                    r_step.id_dependency_step,
                    COALESCE(v_ds_dependency_status, 'NON TROVATO')
                );

                /*
                 * Registra il log dello step con la routine comune su LOG_DBLINK, quindi
                 * aggiorna esito e messaggio dallo stesso canale indipendente. Anche gli
                 * esiti FAILED e SKIPPED restano cosi disponibili dopo un rollback.
                 */
                v_chain_error_message := v_error_message;
                v_step_log_id := hcbi_utility.pkg_log_fnc_insert_log(
                    v_id_log,
                    p_id_chain,
                    r_step.id_step,
                    COALESCE(r_step.ds_step_name, 'STEP_' || r_step.id_step),
                    clock_timestamp()::timestamp,
                    clock_timestamp()::timestamp,
                    session_user
                );

                CALL hcbi_utility.pkg_log_prc_error_update_log(
                    v_step_log_id,
                    'SKIPPED',
                    left(v_error_message, 4000),
                    clock_timestamp()::timestamp,
                    session_user
                );

                RAISE NOTICE
                    'Step % saltato: %',
                    r_step.id_step,
                    v_error_message;

                IF COALESCE(r_step.fl_blocking, 'Y') = 'Y' THEN
                    v_blocking_error := true;
                    EXIT;
                ELSE
                    v_non_blocking_error := true;
                    CONTINUE;
                END IF;
            END IF;
        END IF;

        ------------------------------------------------------------------
        -- Individuazione dello schema e del package
        --
        -- Formati ammessi per DS_PACKAGE_NAME:
        --
        --   hcbi_ras.pkg_nome
        --   pkg_nome
        --
        -- Se lo schema non è specificato, si assume hcbi_ras.
        ------------------------------------------------------------------
        IF strpos(r_step.ds_package_name, '.') > 0 THEN
            v_schema_name :=
                lower(
                    btrim(
                        split_part(r_step.ds_package_name, '.', 1)
                    )
                );

            v_package_name :=
                lower(
                    btrim(
                        split_part(r_step.ds_package_name, '.', 2)
                    )
                );
        ELSE
            v_schema_name  := 'hcbi_ras';
            v_package_name := lower(btrim(r_step.ds_package_name));
        END IF;

        ------------------------------------------------------------------
        -- Validazione dei nomi usati per l'esecuzione dinamica
        ------------------------------------------------------------------
        IF v_schema_name !~ '^[a-z_][a-z0-9_]*$' THEN
            v_error_message := format(
                'Nome schema non valido per lo step %s: %s',
                r_step.id_step,
                v_schema_name
            );

            /*
             * Registra il log dello step con la routine comune su LOG_DBLINK, quindi
             * aggiorna esito e messaggio dallo stesso canale indipendente. Anche gli
             * esiti FAILED e SKIPPED restano cosi disponibili dopo un rollback.
             */
            v_chain_error_message := v_error_message;
            v_step_log_id := hcbi_utility.pkg_log_fnc_insert_log(
                v_id_log,
                p_id_chain,
                r_step.id_step,
                COALESCE(r_step.ds_step_name, 'STEP_' || r_step.id_step),
                clock_timestamp()::timestamp,
                clock_timestamp()::timestamp,
                session_user
            );

            CALL hcbi_utility.pkg_log_prc_error_update_log(
                v_step_log_id,
                'FAILED',
                left(v_error_message, 4000),
                clock_timestamp()::timestamp,
                session_user
            );

            IF COALESCE(r_step.fl_blocking, 'Y') = 'Y' THEN
                v_blocking_error := true;
                EXIT;
            ELSE
                v_non_blocking_error := true;
                CONTINUE;
            END IF;
        END IF;

        IF v_package_name !~ '^[a-z_][a-z0-9_]*$' THEN
            v_error_message := format(
                'Nome package non valido per lo step %s: %s',
                r_step.id_step,
                v_package_name
            );

            /*
             * Registra il log dello step con la routine comune su LOG_DBLINK, quindi
             * aggiorna esito e messaggio dallo stesso canale indipendente. Anche gli
             * esiti FAILED e SKIPPED restano cosi disponibili dopo un rollback.
             */
            v_chain_error_message := v_error_message;
            v_step_log_id := hcbi_utility.pkg_log_fnc_insert_log(
                v_id_log,
                p_id_chain,
                r_step.id_step,
                COALESCE(r_step.ds_step_name, 'STEP_' || r_step.id_step),
                clock_timestamp()::timestamp,
                clock_timestamp()::timestamp,
                session_user
            );

            CALL hcbi_utility.pkg_log_prc_error_update_log(
                v_step_log_id,
                'FAILED',
                left(v_error_message, 4000),
                clock_timestamp()::timestamp,
                session_user
            );

            IF COALESCE(r_step.fl_blocking, 'Y') = 'Y' THEN
                v_blocking_error := true;
                EXIT;
            ELSE
                v_non_blocking_error := true;
                CONTINUE;
            END IF;
        END IF;

        ------------------------------------------------------------------
        -- Esecuzione delle tre fasi:
        --
        --   package_prc_initialize
        --   package_prc_main
        --   package_prc_finalize
        ------------------------------------------------------------------
        FOREACH v_procedure_phase
        IN ARRAY v_procedure_phases
        LOOP
            v_result         := NULL;
            v_error_message  := NULL;
            v_error_detail   := NULL;
            v_error_hint     := NULL;
            v_error_context  := NULL;
            v_sqlstate       := NULL;

            v_procedure_name :=
                v_package_name || '_' || v_procedure_phase;

            v_ds_step_name :=
                COALESCE(
                    NULLIF(btrim(r_step.ds_step_name), ''),
                    v_package_name
                )
                || '.'
                || v_procedure_phase;

            ----------------------------------------------------------------
            -- Verifica dell'esistenza della procedura con la firma prevista
            ----------------------------------------------------------------
			----------------------------------------------------------------
			-- ATTENZIONE
			--
			-- La verifica viene effettuata utilizzando solo i parametri IN.
			--
			-- Le procedure richiamate dalla catena sono attualmente
			-- definite con la seguente firma:
			--
			--   IN  p_id_chain_log bigint
			--   IN  p_id_chain     bigint
			--   IN  p_id_step      bigint
			--   IN  p_ds_step_name varchar
			--   OUT p_result       integer
			--
			-- PostgreSQL identifica correttamente la procedura tramite i
			-- soli parametri IN.
			--
			-- In caso di future modifiche della firma (ad esempio rimozione
			-- o variazione del parametro OUT p_result) questa verifica
			-- continuerebbe comunque a trovare la procedura.
			--
			-- Qualsiasi modifica della firma dovrà essere verificata anche
			-- nella EXECUTE dinamica e nella gestione di v_result.
			----------------------------------------------------------------

            IF to_regprocedure(
                format(
                    '%I.%I(bigint,bigint,bigint,character varying)',
                    v_schema_name,
                    v_procedure_name
                )
            ) IS NULL THEN
                v_error_message := format(
					'Procedura %I.%I(bigint,bigint,bigint,character varying,bigint) non trovata' ,--aggiunto bigint che è il parametro in output omesso nella to_regprocedure
                    v_schema_name,
                    v_procedure_name
                );

                /*
                 * Registra il log dello step con la routine comune su LOG_DBLINK, quindi
                 * aggiorna esito e messaggio dallo stesso canale indipendente. Anche gli
                 * esiti FAILED e SKIPPED restano cosi disponibili dopo un rollback.
                 */
                v_chain_error_message := v_error_message;
                v_step_log_id := hcbi_utility.pkg_log_fnc_insert_log(
                    v_id_log,
                    p_id_chain,
                    r_step.id_step,
                    v_ds_step_name,
                    clock_timestamp()::timestamp,
                    clock_timestamp()::timestamp,
                    session_user
                );

                CALL hcbi_utility.pkg_log_prc_error_update_log(
                    v_step_log_id,
                    'FAILED',
                    left(v_error_message, 4000),
                    clock_timestamp()::timestamp,
                    session_user
                );

                RAISE WARNING '%', v_error_message;

                IF COALESCE(r_step.fl_blocking, 'Y') = 'Y' THEN
                    v_blocking_error := true;
                    EXIT;
                ELSE
                    v_non_blocking_error := true;
                    EXIT;
                END IF;
            END IF;

            ----------------------------------------------------------------
            -- Costruzione e chiamata dinamica della procedura
            --
            -- L'ultimo parametro corrisponde a OUT p_result.
            -- CALL restituisce il parametro OUT come singola riga.
            ----------------------------------------------------------------
			----------------------------------------------------------------
			-- Esecuzione dinamica della procedura.
			--
			-- Le procedure di chain espongono:
			--
			--   IN  p_id_chain_log bigint
			--   IN  p_id_chain     bigint
			--   IN  p_id_step      bigint
			--   IN  p_ds_step_name varchar
			--   OUT p_result       integer
			--
			-- PostgreSQL non aggiorna automaticamente una variabile locale
			-- passata come parametro INOUT tramite EXECUTE dinamica.
			--
			-- Per acquisire correttamente il valore restituito da p_result
			-- viene utilizzata una CALL con quinto parametro NULL:
			--
			--   CALL proc($1,$2,$3,$4,NULL)
			--
			-- Il valore del parametro OUT viene quindi restituito come
			-- record e acquisito mediante:
			--
			--   EXECUTE ... INTO v_result
			--
			-- Questa soluzione è stata validata durante il porting Oracle →
			-- PostgreSQL della PRC_EXECUTE_CHAIN.
			----------------------------------------------------------------
			v_sql := format(
				'CALL %I.%I(
					$1,
					$2,
					$3,
					$4,
					NULL -- Necessario per la risoluzione della firma contenente il parametro OUT p_result.
				)',
				v_schema_name,
				v_procedure_name
			);

            RAISE NOTICE
                'Esecuzione %, chain_log=%, chain=%, step=%, step_name=%',
                format('%I.%I', v_schema_name, v_procedure_name),
                v_id_log,
                p_id_chain,
                r_step.id_step,
                v_ds_step_name;

            BEGIN
                EXECUTE v_sql
                   INTO v_result
                  USING
                      v_id_log,
                      p_id_chain,
                      r_step.id_step,
                      v_ds_step_name;

--RAISE NOTICE 'DEBUG -> procedura=%, result=%',format('%I.%I', v_schema_name, v_procedure_name), coalesce(v_result::text,'NULL');
                ----------------------------------------------------------------
                -- Un valore NULL non è considerato un esito valido
                ----------------------------------------------------------------
                IF v_result IS NULL THEN
                    v_result := -1;

                    v_error_message := format(
                        'La procedura %I.%I non ha restituito p_result',
                        v_schema_name,
                        v_procedure_name
                    );
                ELSIF v_result < 0 THEN
                    v_error_message := format(
                        'La procedura %I.%I ha restituito p_result=%s',
                        v_schema_name,
                        v_procedure_name,
                        v_result
                    );
                ELSE
                    RAISE NOTICE
                        'Procedura % completata con p_result=%',
                        format('%I.%I', v_schema_name, v_procedure_name),
                        v_result;
                END IF;

            EXCEPTION
                WHEN OTHERS THEN
                    GET STACKED DIAGNOSTICS
                        v_error_message = MESSAGE_TEXT,
                        v_error_detail  = PG_EXCEPTION_DETAIL,
                        v_error_hint    = PG_EXCEPTION_HINT,
                        v_error_context = PG_EXCEPTION_CONTEXT,
                        v_sqlstate      = RETURNED_SQLSTATE;

                    v_error_message := concat_ws(
                        ' | ',
                        format(
                            'Errore nella procedura %I.%I',
                            v_schema_name,
                            v_procedure_name
                        ),
                        'SQLSTATE=' || COALESCE(v_sqlstate, SQLSTATE),
                        'SQLERRM=' || COALESCE(v_error_message, SQLERRM),
                        CASE
                            WHEN NULLIF(v_error_detail, '') IS NOT NULL
                            THEN 'DETAIL=' || v_error_detail
                        END,
                        CASE
                            WHEN NULLIF(v_error_hint, '') IS NOT NULL
                            THEN 'HINT=' || v_error_hint
                        END,
                        CASE
                            WHEN NULLIF(v_error_context, '') IS NOT NULL
                            THEN 'CONTEXT=' || v_error_context
                        END
                    );

                    v_result := -1;
            END;

            ----------------------------------------------------------------
            -- Gestione dell'esito negativo della fase
            ----------------------------------------------------------------
            IF COALESCE(v_result, -1) < 0 THEN
                v_chain_error_message := v_error_message;
                CALL hcbi_utility.prc_mark_chain_failed(
                    v_id_log,
                    left(
                        COALESCE(
                            v_error_message,
                            format(
                                'Errore nella procedura %I.%I',
                                v_schema_name,
                                v_procedure_name
                            )
                        ),
                        4000
                    )
                );

                IF COALESCE(r_step.fl_blocking, 'Y') = 'Y' THEN
                    v_blocking_error := true;

                    RAISE 
                        'Interruzione della catena %: errore bloccante nello step %, procedura %',
                        p_id_chain,
                        r_step.id_step,
                        format('%I.%I', v_schema_name, v_procedure_name);

                    EXIT;
                ELSE
                    v_non_blocking_error := true;

                    RAISE WARNING
                        'Errore non bloccante nella catena %, step %, procedura %. L''elaborazione prosegue con lo step successivo',
                        p_id_chain,
                        r_step.id_step,
                        format('%I.%I', v_schema_name, v_procedure_name);

                    EXIT;
                END IF;
            END IF;
        END LOOP;

        ------------------------------------------------------------------
        -- Uscita dal ciclo degli step in caso di errore bloccante
        ------------------------------------------------------------------
        IF v_blocking_error THEN
            EXIT;
        END IF;
    END LOOP;

    ----------------------------------------------------------------------
    -- Chiusura della catena
    ----------------------------------------------------------------------
    IF v_blocking_error THEN
        CALL hcbi_utility.prc_end_chain(
            v_id_log,
            'FAILED',
            left(
                COALESCE(
                    v_chain_error_message,
                    'Catena interrotta a causa di un errore bloccante'
                ),
                4000
            )
        );

        RAISE 
            'Catena % terminata con stato FAILED, id_log=%',
            p_id_chain,
            v_id_log;

    ELSIF v_non_blocking_error THEN
        ------------------------------------------------------------------
        -- La catena ha completato tutti gli step eseguibili, ma almeno
        -- uno step non bloccante è terminato in errore.
        ------------------------------------------------------------------
        CALL hcbi_utility.prc_end_chain(
            v_id_log,
            'FAILED',
            left(
                COALESCE(
                    v_chain_error_message,
                    'Catena completata con piu errori non bloccanti'
                ),
                4000
            )
        );

        RAISE WARNING
            'Catena % completata con errori non bloccanti, id_log=%',
            p_id_chain,
            v_id_log;

    ELSE
        CALL hcbi_utility.prc_end_chain(
            v_id_log,
            'COMPLETED',
            NULL
        );

        RAISE NOTICE
            'Catena % completata correttamente, id_log=%',
            p_id_chain,
            v_id_log;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS
            v_error_message = MESSAGE_TEXT,
            v_error_detail  = PG_EXCEPTION_DETAIL,
            v_error_hint    = PG_EXCEPTION_HINT,
            v_error_context = PG_EXCEPTION_CONTEXT,
            v_sqlstate      = RETURNED_SQLSTATE;

        v_error_message := concat_ws(
            ' | ',
            'Errore durante l''esecuzione della catena ' || p_id_chain,
            'SQLSTATE=' || COALESCE(v_sqlstate, SQLSTATE),
            'SQLERRM=' || COALESCE(v_error_message, SQLERRM),
            CASE
                WHEN NULLIF(v_error_detail, '') IS NOT NULL
                THEN 'DETAIL=' || v_error_detail
            END,
            CASE
                WHEN NULLIF(v_error_hint, '') IS NOT NULL
                THEN 'HINT=' || v_error_hint
            END,
            CASE
                WHEN NULLIF(v_error_context, '') IS NOT NULL
                THEN 'CONTEXT=' || v_error_context
            END
        );

        ------------------------------------------------------------------
        -- Registra l'errore finale tramite la sessione indipendente.
        -- Un eventuale guasto del canale di logging viene segnalato senza
        -- sostituire il messaggio dell'errore originale.
        ------------------------------------------------------------------
        IF v_id_log IS NOT NULL THEN
            BEGIN
                CALL hcbi_utility.prc_end_chain(
                    v_id_log,
                    'FAILED',
                    left(v_error_message, 4000)
                );
            EXCEPTION
                WHEN OTHERS THEN
                    RAISE WARNING
                        'Impossibile aggiornare il log della catena % (id_log=%). '
                        'Errore logging SQLSTATE=%, messaggio=%',
                        p_id_chain,
                        v_id_log,
                        SQLSTATE,
                        SQLERRM;
            END;
        END IF;

        RAISE  '%', v_error_message;


        RETURN;
END;
$_$;


ALTER PROCEDURE hcbi_utility.prc_execute_chain(IN p_id_chain bigint) OWNER TO hcbi_utility;

--
-- TOC entry 693 (class 1255 OID 395991046)
-- Name: prc_grant_to_hcbi_ras(); Type: PROCEDURE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE PROCEDURE hcbi_utility.prc_grant_to_hcbi_ras()
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_sql text;
BEGIN

    ----------------------------------------------------------------------
    -- TABELLE E VISTE
    ----------------------------------------------------------------------
    FOR v_sql IN
        SELECT format(
            'GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE %I.%I TO hcbi_ras;',
            schemaname,
            tablename
        )
        FROM pg_tables
        WHERE schemaname = 'hcbi_utility'
    LOOP
        EXECUTE v_sql;
    END LOOP;

    ----------------------------------------------------------------------
    -- VISTE
    ----------------------------------------------------------------------
    FOR v_sql IN
        SELECT format(
            'GRANT SELECT ON TABLE %I.%I TO hcbi_ras;',
            schemaname,
            viewname
        )
        FROM pg_views
        WHERE schemaname = 'hcbi_utility'
    LOOP
        EXECUTE v_sql;
    END LOOP;

    ----------------------------------------------------------------------
    -- MATERIALIZED VIEW
    ----------------------------------------------------------------------
    FOR v_sql IN
        SELECT format(
            'GRANT SELECT ON TABLE %I.%I TO hcbi_ras;',
            schemaname,
            matviewname
        )
        FROM pg_matviews
        WHERE schemaname = 'hcbi_utility'
    LOOP
        EXECUTE v_sql;
    END LOOP;

    ----------------------------------------------------------------------
    -- SEQUENCE
    ----------------------------------------------------------------------
    FOR v_sql IN
        SELECT format(
            'GRANT USAGE, SELECT, UPDATE ON SEQUENCE %I.%I TO hcbi_ras;',
            sequence_schema,
            sequence_name
        )
        FROM information_schema.sequences
        WHERE sequence_schema = 'hcbi_utility'
    LOOP
        EXECUTE v_sql;
    END LOOP;

    ----------------------------------------------------------------------
    -- FUNZIONI
    ----------------------------------------------------------------------

    FOR v_sql IN
        SELECT format(
            'GRANT EXECUTE ON FUNCTION %I.%I(%s) TO hcbi_ras;',
            n.nspname,
            p.proname,
            pg_get_function_identity_arguments(p.oid)
        )
        FROM pg_proc p
        JOIN pg_namespace n
            ON n.oid = p.pronamespace
        WHERE n.nspname = 'hcbi_utility' 
		  and p.proname not like '%dblink%'
          AND p.prokind = 'f'
    LOOP
        EXECUTE v_sql;
    END LOOP;

    ----------------------------------------------------------------------
    -- PROCEDURE
    ----------------------------------------------------------------------
    FOR v_sql IN
        SELECT format(
            'GRANT EXECUTE ON PROCEDURE %I.%I(%s) TO hcbi_ras;',
            n.nspname,
            p.proname,
            pg_get_function_identity_arguments(p.oid)
        )
        FROM pg_proc p
        JOIN pg_namespace n
            ON n.oid = p.pronamespace
        WHERE n.nspname = 'hcbi_utility'
          AND p.prokind = 'p'
    LOOP
        EXECUTE v_sql;
    END LOOP;

END;
$$;


ALTER PROCEDURE hcbi_utility.prc_grant_to_hcbi_ras() OWNER TO hcbi_utility;

--
-- TOC entry 556 (class 1255 OID 398688993)
-- Name: prc_mark_chain_failed(bigint, text); Type: PROCEDURE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE PROCEDURE hcbi_utility.prc_mark_chain_failed(IN p_id_log bigint, IN p_error_msg text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $_$
DECLARE
    v_sql          text;
    v_exec_result  text;
    v_sqlstate     text;
    v_sqlerrm      text;
BEGIN
    IF p_id_log IS NULL THEN
        RAISE EXCEPTION
            'PRC_MARK_CHAIN_FAILED: p_id_log obbligatorio';
    END IF;

    /*
     * Questo helper registra il fallimento di uno step senza chiudere
     * anticipatamente il log della catena. prc_execute_chain continua a
     * decidere se interrompere o proseguire con gli step successivi e
     * richiama prc_end_chain alla conclusione per valorizzare dt_end.
     *
     * L'UPDATE passa da LOG_DBLINK, cosi' lo stato FAILED e il messaggio
     * restano registrati anche se la transazione principale fa rollback.
     */
    PERFORM hcbi_utility.ensure_dblink_logging();

    v_sql := format(
        $sql$
        UPDATE hcbi_utility.log_chain
           SET ds_status = 'FAILED',
               tx_error_message = left(%L::text, 4000)
         WHERE id_log = %L::bigint
        $sql$,
        p_error_msg,
        p_id_log
    );

    v_exec_result := hcbi_utility.dblink_exec('LOG_DBLINK', v_sql);

    IF v_exec_result = 'UPDATE 0' THEN
        RAISE EXCEPTION
            'PRC_MARK_CHAIN_FAILED: nessuna riga LOG_CHAIN trovata per ID_LOG=%',
            p_id_log;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        v_sqlstate := SQLSTATE;
        v_sqlerrm := SQLERRM;

        RAISE EXCEPTION
            'PRC_MARK_CHAIN_FAILED: errore aggiornamento LOG_CHAIN ID_LOG=%. SQLSTATE: %, errore: %',
            p_id_log,
            v_sqlstate,
            v_sqlerrm;
END;
$_$;


ALTER PROCEDURE hcbi_utility.prc_mark_chain_failed(IN p_id_log bigint, IN p_error_msg text) OWNER TO hcbi_utility;

--
-- TOC entry 488 (class 1255 OID 395991047)
-- Name: prc_start_chain(bigint); Type: PROCEDURE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE PROCEDURE hcbi_utility.prc_start_chain(IN p_id_chain bigint, OUT p_id_log bigint)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'hcbi_utility'
    AS $_$
	DECLARE
		v_sql            TEXT;
		v_running_count  BIGINT;
		v_execution_uuid UUID;
	BEGIN

		p_id_log := NULL;

		IF p_id_chain IS NULL THEN
			RAISE EXCEPTION
			'PRC_START_CHAIN: p_id_chain obbligatorio';
		END IF;

		PERFORM hcbi_utility.ensure_dblink_logging();

		/*
		 * Legge l'UUID nella sessione chiamante prima dell'INSERT remoto.
		 * Il valore non dipende da eventuali variabili di sessione del
		 * collegamento LOG_DBLINK, che e' una sessione PostgreSQL distinta.
		 */
		v_execution_uuid := hcbi_utility.get_current_etl_execution_uuid();

		/*
		 * Difesa aggiuntiva contro chiamate dirette o versioni concorrenti.
		 * prc_execute_chain acquisisce prima il lock advisory e riconcilia
		 * i vecchi log IN_PROGRESS; qui si verifica comunque sul database
		 * remoto che non sia rimasta un'esecuzione registrata come attiva.
		 */
		v_sql := format(
			$SQL$
			SELECT count(*)
			FROM hcbi_utility.log_chain
			WHERE id_chain = %L
			  AND ds_status = 'IN_PROGRESS'
			$SQL$,
			p_id_chain
		);

		SELECT r.running_count
		  INTO v_running_count
		  FROM hcbi_utility.dblink(
				  'LOG_DBLINK',
				  v_sql
			   ) AS r(running_count BIGINT);

		IF COALESCE(v_running_count,0) > 0 THEN

			RAISE EXCEPTION
			'Catena % già in esecuzione',
			p_id_chain;

		END IF;

		/*
		 * Apertura durevole del log della catena.
		 * L'INSERT e' eseguito tramite LOG_DBLINK, in una sessione separata:
		 * un rollback della transazione principale non annulla questa riga.
		 * I valori sono formattati con %L per gestire UUID, identificativi
		 * e testi in modo sicuro, inclusi NULL e caratteri speciali.
		 */
		v_sql := format(
			$SQL$
			INSERT INTO hcbi_utility.log_chain
			(
				id_chain,
				etl_execution_uuid,
				dt_start,
				dt_end,
				ds_status,
				tx_error_message,
				dt_creation,
				tx_creation_by
			)
			VALUES
			(
				%L::bigint,
				%L::uuid,
				clock_timestamp(),
				NULL,
				'IN_PROGRESS',
				NULL,
				clock_timestamp(),
				%L::text
			)
			RETURNING id_log
			$SQL$,
			p_id_chain,
			v_execution_uuid,
			session_user
		);

		SELECT r.id_log
		  INTO p_id_log
		  FROM hcbi_utility.dblink(
				'LOG_DBLINK',
				v_sql
		  ) AS r(id_log BIGINT);

	END;
	$_$;


ALTER PROCEDURE hcbi_utility.prc_start_chain(IN p_id_chain bigint, OUT p_id_log bigint) OWNER TO hcbi_utility;

--
-- TOC entry 721 (class 1255 OID 395991048)
-- Name: test_p(integer, integer); Type: PROCEDURE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE PROCEDURE hcbi_utility.test_p(IN p_id integer, INOUT p_result integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    p_result := -999;
END;
$$;


ALTER PROCEDURE hcbi_utility.test_p(IN p_id integer, INOUT p_result integer) OWNER TO hcbi_utility;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 417 (class 1259 OID 395992207)
-- Name: cfg_connections; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.cfg_connections (
    conn_name character varying(100) NOT NULL,
    conn_string text
);


ALTER TABLE hcbi_utility.cfg_connections OWNER TO hcbi_utility;

--
-- TOC entry 478 (class 1259 OID 398901487)
-- Name: dwh_schedule; Type: TABLE; Schema: hcbi_utility; Owner: postgres
--

CREATE TABLE hcbi_utility.dwh_schedule (
    schedule_id bigint NOT NULL,
    process_code character varying(100) NOT NULL,
    process_description character varying(500) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    frequency_code character varying(20) NOT NULL,
    anchor_month smallint,
    week_ordinal smallint,
    weekday_iso smallint,
    retry_days smallint,
    last_success_at timestamp with time zone,
    last_success_period_start date,
    last_attempt_at timestamp with time zone,
    last_attempt_status character varying(20),
    last_error_message character varying(4000),
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT ck_dwh_schedule_anchor CHECK (((anchor_month IS NULL) OR ((anchor_month >= 1) AND (anchor_month <= 12)))),
    CONSTRAINT ck_dwh_schedule_frequency CHECK (((frequency_code)::text = ANY ((ARRAY['ANNUAL'::character varying, 'SEMIANNUAL'::character varying, 'FOUR_MONTHLY'::character varying, 'QUARTERLY'::character varying, 'BIMONTHLY'::character varying, 'MONTHLY'::character varying, 'WEEKLY'::character varying, 'DAILY'::character varying])::text[]))),
    CONSTRAINT ck_dwh_schedule_retry CHECK (((retry_days IS NULL) OR (retry_days >= 0))),
    CONSTRAINT ck_dwh_schedule_shape CHECK (((((frequency_code)::text = 'DAILY'::text) AND (anchor_month IS NULL) AND (week_ordinal IS NULL) AND (weekday_iso IS NULL) AND (retry_days IS NULL)) OR (((frequency_code)::text = 'WEEKLY'::text) AND (anchor_month IS NULL) AND (week_ordinal IS NULL) AND (weekday_iso IS NOT NULL) AND (retry_days IS NOT NULL)) OR (((frequency_code)::text = 'MONTHLY'::text) AND (anchor_month IS NULL) AND (week_ordinal IS NOT NULL) AND (weekday_iso IS NOT NULL) AND (retry_days IS NOT NULL)) OR (((frequency_code)::text = ANY ((ARRAY['ANNUAL'::character varying, 'SEMIANNUAL'::character varying, 'FOUR_MONTHLY'::character varying, 'QUARTERLY'::character varying, 'BIMONTHLY'::character varying])::text[])) AND (anchor_month IS NOT NULL) AND (week_ordinal IS NOT NULL) AND (weekday_iso IS NOT NULL) AND (retry_days IS NOT NULL)))),
    CONSTRAINT ck_dwh_schedule_status CHECK (((last_attempt_status IS NULL) OR ((last_attempt_status)::text = ANY ((ARRAY['RUNNING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'SKIPPED'::character varying])::text[])))),
    CONSTRAINT ck_dwh_schedule_week CHECK (((week_ordinal IS NULL) OR ((week_ordinal >= 1) AND (week_ordinal <= 5)))),
    CONSTRAINT ck_dwh_schedule_weekday CHECK (((weekday_iso IS NULL) OR ((weekday_iso >= 1) AND (weekday_iso <= 7))))
);


ALTER TABLE hcbi_utility.dwh_schedule OWNER TO postgres;

--
-- TOC entry 479 (class 1259 OID 398901507)
-- Name: dwh_schedule_run; Type: TABLE; Schema: hcbi_utility; Owner: postgres
--

CREATE TABLE hcbi_utility.dwh_schedule_run (
    run_id uuid NOT NULL,
    schedule_id bigint NOT NULL,
    process_code character varying(100) NOT NULL,
    planned_date date,
    trigger_source character varying(20) DEFAULT 'SCHEDULED'::character varying NOT NULL,
    requested_by character varying(255),
    period_start date,
    period_end date,
    started_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    finished_at timestamp with time zone,
    status character varying(20) NOT NULL,
    return_code integer,
    duration_ms bigint,
    error_message character varying(4000),
    CONSTRAINT ck_dwh_schedule_run_dates CHECK (((period_end IS NULL) OR (period_start IS NULL) OR (period_end >= period_start))),
    CONSTRAINT ck_dwh_schedule_run_duration CHECK (((duration_ms IS NULL) OR (duration_ms >= 0))),
    CONSTRAINT ck_dwh_schedule_run_lifecycle CHECK (((((status)::text = 'RUNNING'::text) AND (finished_at IS NULL) AND (return_code IS NULL)) OR (((status)::text <> 'RUNNING'::text) AND (finished_at IS NOT NULL)))),
    CONSTRAINT ck_dwh_schedule_run_status CHECK (((status)::text = ANY ((ARRAY['RUNNING'::character varying, 'SUCCESS'::character varying, 'FAILED'::character varying, 'SKIPPED'::character varying])::text[]))),
    CONSTRAINT ck_dwh_schedule_run_trigger_source CHECK (((trigger_source)::text = ANY ((ARRAY['SCHEDULED'::character varying, 'MANUAL_UI'::character varying])::text[])))
);


ALTER TABLE hcbi_utility.dwh_schedule_run OWNER TO postgres;

--
-- TOC entry 477 (class 1259 OID 398901486)
-- Name: dwh_schedule_schedule_id_seq; Type: SEQUENCE; Schema: hcbi_utility; Owner: postgres
--

ALTER TABLE hcbi_utility.dwh_schedule ALTER COLUMN schedule_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hcbi_utility.dwh_schedule_schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 437 (class 1259 OID 396127220)
-- Name: etl_dwh_refresh_run; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.etl_dwh_refresh_run (
    run_id bigint NOT NULL,
    execution_uuid uuid NOT NULL,
    chain_id integer NOT NULL,
    started_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    ended_at timestamp with time zone,
    status character varying(20) DEFAULT 'RUNNING'::character varying NOT NULL,
    error_message text,
    CONSTRAINT ck_etl_dwh_refresh_run_chain CHECK ((chain_id > 0)),
    CONSTRAINT ck_etl_dwh_refresh_run_closed CHECK (((((status)::text = ANY ((ARRAY['SUCCEEDED'::character varying, 'FAILED'::character varying, 'SKIPPED'::character varying])::text[])) AND (ended_at IS NOT NULL)) OR ((status)::text = 'RUNNING'::text))),
    CONSTRAINT ck_etl_dwh_refresh_run_dates CHECK (((ended_at IS NULL) OR (ended_at >= started_at))),
    CONSTRAINT ck_etl_dwh_refresh_run_error CHECK (((((status)::text = 'FAILED'::text) AND (error_message IS NOT NULL)) OR ((status)::text <> 'FAILED'::text))),
    CONSTRAINT ck_etl_dwh_refresh_run_running CHECK (((((status)::text = 'RUNNING'::text) AND (ended_at IS NULL)) OR ((status)::text <> 'RUNNING'::text))),
    CONSTRAINT ck_etl_dwh_refresh_run_status CHECK (((status)::text = ANY ((ARRAY['RUNNING'::character varying, 'SUCCEEDED'::character varying, 'FAILED'::character varying, 'SKIPPED'::character varying])::text[])))
);


ALTER TABLE hcbi_utility.etl_dwh_refresh_run OWNER TO hcbi_utility;

--
-- TOC entry 5560 (class 0 OID 0)
-- Dependencies: 437
-- Name: TABLE etl_dwh_refresh_run; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.etl_dwh_refresh_run IS 'Tracciamento esecuzioni della procedura DWH hcbi_utility.prc_execute_chain.';


--
-- TOC entry 436 (class 1259 OID 396127219)
-- Name: etl_dwh_refresh_run_run_id_seq; Type: SEQUENCE; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE hcbi_utility.etl_dwh_refresh_run ALTER COLUMN run_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hcbi_utility.etl_dwh_refresh_run_run_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 483 (class 1259 OID 399416116)
-- Name: etl_execution_log_event; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.etl_execution_log_event (
    event_id bigint NOT NULL,
    ingestion_id bigint NOT NULL,
    source_code character varying(50) NOT NULL,
    source_path text NOT NULL,
    source_device bigint NOT NULL,
    source_inode bigint NOT NULL,
    byte_offset_start bigint NOT NULL,
    byte_offset_end bigint NOT NULL,
    source_line_start bigint,
    source_line_end bigint,
    event_timestamp timestamp with time zone,
    log_level character varying(20),
    event_execution_uuid uuid,
    manifest_execution_uuid uuid,
    event_scheduler_run_id uuid,
    manifest_scheduler_run_id uuid,
    chain_id integer,
    process_name character varying(255),
    cycle_exit_code integer,
    correlation_status character varying(30) NOT NULL,
    parse_status character varying(30) NOT NULL,
    is_redacted boolean DEFAULT false NOT NULL,
    message_text text NOT NULL,
    event_hash character(64) NOT NULL,
    ingested_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT ck_etl_execution_log_event_correlation CHECK (((correlation_status)::text = ANY ((ARRAY['CORRELATED'::character varying, 'UNCORRELATED'::character varying, 'AMBIGUOUS'::character varying, 'NOT_APPLICABLE'::character varying])::text[]))),
    CONSTRAINT ck_etl_execution_log_event_hash CHECK ((event_hash ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT ck_etl_execution_log_event_lines CHECK (((source_line_start IS NULL) OR (source_line_end IS NULL) OR (source_line_end >= source_line_start))),
    CONSTRAINT ck_etl_execution_log_event_offsets CHECK (((byte_offset_start >= 0) AND (byte_offset_end > byte_offset_start))),
    CONSTRAINT ck_etl_execution_log_event_parse CHECK (((parse_status)::text = ANY ((ARRAY['PARSED'::character varying, 'UNPARSED'::character varying, 'ENCODING_REPLACED'::character varying])::text[])))
);


ALTER TABLE hcbi_utility.etl_execution_log_event OWNER TO hcbi_utility;

--
-- TOC entry 5563 (class 0 OID 0)
-- Dependencies: 483
-- Name: TABLE etl_execution_log_event; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.etl_execution_log_event IS 'Eventi logici acquisiti dai segmenti dei log NiFi/FMR e scheduler DWH.';


--
-- TOC entry 5564 (class 0 OID 0)
-- Dependencies: 483
-- Name: COLUMN etl_execution_log_event.message_text; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.etl_execution_log_event.message_text IS 'Testo dell''evento con redazione automatica dei pattern di segreti noti.';


--
-- TOC entry 482 (class 1259 OID 399416115)
-- Name: etl_execution_log_event_event_id_seq; Type: SEQUENCE; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE hcbi_utility.etl_execution_log_event ALTER COLUMN event_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hcbi_utility.etl_execution_log_event_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 481 (class 1259 OID 399416087)
-- Name: etl_execution_log_ingestion; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.etl_execution_log_ingestion (
    ingestion_id bigint NOT NULL,
    source_code character varying(50) NOT NULL,
    source_path text NOT NULL,
    source_device bigint,
    source_inode bigint,
    offset_start bigint NOT NULL,
    offset_end bigint NOT NULL,
    manifest_execution_uuid uuid,
    scheduler_run_id uuid,
    cycle_result character varying(20),
    cycle_exit_code integer,
    started_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    finished_at timestamp with time zone,
    status character varying(30) DEFAULT 'RUNNING'::character varying NOT NULL,
    events_read bigint DEFAULT 0 NOT NULL,
    events_inserted bigint DEFAULT 0 NOT NULL,
    events_duplicate bigint DEFAULT 0 NOT NULL,
    events_rejected bigint DEFAULT 0 NOT NULL,
    bytes_read bigint DEFAULT 0 NOT NULL,
    error_code character varying(50),
    error_message character varying(4000),
    retry_of_ingestion_id bigint,
    CONSTRAINT ck_etl_execution_log_ingestion_bytes CHECK (((events_read >= 0) AND (events_inserted >= 0) AND (events_duplicate >= 0) AND (events_rejected >= 0) AND (bytes_read >= 0))),
    CONSTRAINT ck_etl_execution_log_ingestion_counts CHECK ((events_read = ((events_inserted + events_duplicate) + events_rejected))),
    CONSTRAINT ck_etl_execution_log_ingestion_dates CHECK (((finished_at IS NULL) OR (finished_at >= started_at))),
    CONSTRAINT ck_etl_execution_log_ingestion_lifecycle CHECK (((((status)::text = 'RUNNING'::text) AND (finished_at IS NULL)) OR (((status)::text <> 'RUNNING'::text) AND (finished_at IS NOT NULL)))),
    CONSTRAINT ck_etl_execution_log_ingestion_offsets CHECK (((offset_start >= 0) AND (offset_end >= offset_start))),
    CONSTRAINT ck_etl_execution_log_ingestion_result CHECK (((cycle_result IS NULL) OR ((cycle_result)::text = ANY ((ARRAY['SUCCESS'::character varying, 'FAILED'::character varying, 'SKIPPED'::character varying])::text[])))),
    CONSTRAINT ck_etl_execution_log_ingestion_status CHECK (((status)::text = ANY ((ARRAY['RUNNING'::character varying, 'SUCCEEDED'::character varying, 'SUCCEEDED_WITH_REJECTS'::character varying, 'FAILED'::character varying, 'ROTATED'::character varying, 'SKIPPED'::character varying])::text[])))
);


ALTER TABLE hcbi_utility.etl_execution_log_ingestion OWNER TO hcbi_utility;

--
-- TOC entry 5567 (class 0 OID 0)
-- Dependencies: 481
-- Name: TABLE etl_execution_log_ingestion; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.etl_execution_log_ingestion IS 'Audit dei tentativi di acquisizione dei segmenti dei log FMR/DWH.';


--
-- TOC entry 480 (class 1259 OID 399416086)
-- Name: etl_execution_log_ingestion_ingestion_id_seq; Type: SEQUENCE; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE hcbi_utility.etl_execution_log_ingestion ALTER COLUMN ingestion_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hcbi_utility.etl_execution_log_ingestion_ingestion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 430 (class 1259 OID 396106603)
-- Name: etl_frontiere_config; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.etl_frontiere_config (
    frontiera_code character varying(100) NOT NULL,
    description character varying(500) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    execution_order integer DEFAULT 100 NOT NULL,
    source_service_code character varying(50) NOT NULL,
    source_query text NOT NULL,
    target_schema character varying(63) DEFAULT 'hcbi_ras'::character varying NOT NULL,
    target_table character varying(63) NOT NULL,
    truncate_before_load boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    created_by character varying(100) DEFAULT CURRENT_USER NOT NULL,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    updated_by character varying(100) DEFAULT CURRENT_USER NOT NULL,
    CONSTRAINT ck_etl_frontiere_config_code CHECK (((frontiera_code)::text ~ '^[A-Z][A-Z0-9_]{1,99}$'::text)),
    CONSTRAINT ck_etl_frontiere_config_full_refresh CHECK ((truncate_before_load = true)),
    CONSTRAINT ck_etl_frontiere_config_order CHECK ((execution_order >= 0)),
    CONSTRAINT ck_etl_frontiere_config_source_query CHECK ((length(btrim(source_query)) > 0)),
    CONSTRAINT ck_etl_frontiere_config_source_service CHECK (((source_service_code)::text ~ '^[A-Z][A-Z0-9_]{1,49}$'::text)),
    CONSTRAINT ck_etl_frontiere_config_target_schema CHECK (((target_schema)::text = 'hcbi_ras'::text)),
    CONSTRAINT ck_etl_frontiere_config_target_table CHECK (((target_table)::text ~ '^[a-z_][a-z0-9_]{0,62}$'::text))
);


ALTER TABLE hcbi_utility.etl_frontiere_config OWNER TO hcbi_utility;

--
-- TOC entry 5570 (class 0 OID 0)
-- Dependencies: 430
-- Name: TABLE etl_frontiere_config; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.etl_frontiere_config IS 'Configurazione minima delle frontiere NiFi caricate in full refresh.';


--
-- TOC entry 5571 (class 0 OID 0)
-- Dependencies: 430
-- Name: COLUMN etl_frontiere_config.source_query; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.etl_frontiere_config.source_query IS 'Query completa di sola lettura eseguita sul servizio sorgente configurato.';


--
-- TOC entry 5572 (class 0 OID 0)
-- Dependencies: 430
-- Name: COLUMN etl_frontiere_config.target_table; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.etl_frontiere_config.target_table IS 'Tabella di pre-staging nello schema hcbi_ras.';


--
-- TOC entry 435 (class 1259 OID 396106719)
-- Name: etl_frontiere_execution_lock; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.etl_frontiere_execution_lock (
    frontiera_code character varying(100) NOT NULL,
    run_id bigint NOT NULL,
    acquired_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    acquired_by character varying(100) DEFAULT CURRENT_USER NOT NULL
);


ALTER TABLE hcbi_utility.etl_frontiere_execution_lock OWNER TO hcbi_utility;

--
-- TOC entry 5574 (class 0 OID 0)
-- Dependencies: 435
-- Name: TABLE etl_frontiere_execution_lock; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.etl_frontiere_execution_lock IS 'Lock applicativo: al massimo un full refresh attivo per frontiera.';


--
-- TOC entry 434 (class 1259 OID 396106696)
-- Name: etl_frontiere_run; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.etl_frontiere_run (
    run_id bigint NOT NULL,
    frontiera_code character varying(100) NOT NULL,
    started_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    ended_at timestamp with time zone,
    status character varying(20) DEFAULT 'RUNNING'::character varying NOT NULL,
    rows_read bigint,
    rows_written bigint,
    error_message text,
    warning_message text,
    nifi_flowfile_uuid character varying(100),
    CONSTRAINT ck_etl_frontiere_run_closed CHECK (((((status)::text = ANY (ARRAY[('SUCCEEDED'::character varying)::text, ('FAILED'::character varying)::text, ('SKIPPED'::character varying)::text])) AND (ended_at IS NOT NULL)) OR ((status)::text = 'RUNNING'::text))),
    CONSTRAINT ck_etl_frontiere_run_dates CHECK (((ended_at IS NULL) OR (ended_at >= started_at))),
    CONSTRAINT ck_etl_frontiere_run_error CHECK (((((status)::text = 'FAILED'::text) AND (error_message IS NOT NULL)) OR ((status)::text <> 'FAILED'::text))),
    CONSTRAINT ck_etl_frontiere_run_rows_read CHECK (((rows_read IS NULL) OR (rows_read >= 0))),
    CONSTRAINT ck_etl_frontiere_run_rows_written CHECK (((rows_written IS NULL) OR (rows_written >= 0))),
    CONSTRAINT ck_etl_frontiere_run_running CHECK (((((status)::text = 'RUNNING'::text) AND (ended_at IS NULL)) OR ((status)::text <> 'RUNNING'::text))),
    CONSTRAINT ck_etl_frontiere_run_status CHECK (((status)::text = ANY (ARRAY[('RUNNING'::character varying)::text, ('SUCCEEDED'::character varying)::text, ('FAILED'::character varying)::text, ('SKIPPED'::character varying)::text])))
);


ALTER TABLE hcbi_utility.etl_frontiere_run OWNER TO hcbi_utility;

--
-- TOC entry 5576 (class 0 OID 0)
-- Dependencies: 434
-- Name: TABLE etl_frontiere_run; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.etl_frontiere_run IS 'Log tecnico di ogni tentativo di caricamento full refresh.';


--
-- TOC entry 433 (class 1259 OID 396106695)
-- Name: etl_frontiere_run_run_id_seq; Type: SEQUENCE; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE hcbi_utility.etl_frontiere_run ALTER COLUMN run_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME hcbi_utility.etl_frontiere_run_run_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 418 (class 1259 OID 395992212)
-- Name: seq_log_chain; Type: SEQUENCE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE SEQUENCE hcbi_utility.seq_log_chain
    START WITH 4025
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hcbi_utility.seq_log_chain OWNER TO hcbi_utility;

--
-- TOC entry 419 (class 1259 OID 395992213)
-- Name: log_chain; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.log_chain (
    id_log bigint DEFAULT nextval('hcbi_utility.seq_log_chain'::regclass) NOT NULL,
    id_chain bigint,
    dt_start timestamp without time zone,
    dt_end timestamp without time zone,
    ds_status character varying(500),
    tx_error_message character varying(4000),
    dt_creation timestamp without time zone DEFAULT clock_timestamp() NOT NULL,
    tx_creation_by character varying(4000),
    dt_update timestamp without time zone,
    tx_update_by character varying(4000),
    etl_execution_uuid uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL
);


ALTER TABLE hcbi_utility.log_chain OWNER TO hcbi_utility;

--
-- TOC entry 5580 (class 0 OID 0)
-- Dependencies: 419
-- Name: TABLE log_chain; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.log_chain IS 'Tabella di log Chain';


--
-- TOC entry 420 (class 1259 OID 395992220)
-- Name: seq_log_step; Type: SEQUENCE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE SEQUENCE hcbi_utility.seq_log_step
    START WITH 652866
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hcbi_utility.seq_log_step OWNER TO hcbi_utility;

--
-- TOC entry 421 (class 1259 OID 395992221)
-- Name: log_step; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.log_step (
    id_log bigint DEFAULT nextval('hcbi_utility.seq_log_step'::regclass) NOT NULL,
    id_chain_log bigint,
    id_chain bigint,
    id_step bigint,
    ds_step_name character varying(500),
    dt_start timestamp without time zone,
    dt_end timestamp without time zone,
    ds_status character varying(500),
    tx_error_message character varying(4000),
    nr_rec_selected bigint,
    nr_rec_inserted bigint,
    nr_rec_updated bigint,
    nr_rec_deleted bigint,
    nr_rec_errors bigint,
    dt_creation timestamp without time zone DEFAULT clock_timestamp(),
    tx_creation_by character varying(4000),
    dt_update timestamp without time zone,
    tx_update_by character varying(4000)
);


ALTER TABLE hcbi_utility.log_step OWNER TO hcbi_utility;

--
-- TOC entry 5583 (class 0 OID 0)
-- Dependencies: 421
-- Name: TABLE log_step; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.log_step IS 'Tabella di log Step';


--
-- TOC entry 422 (class 1259 OID 395992228)
-- Name: seq_srv_config_step; Type: SEQUENCE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE SEQUENCE hcbi_utility.seq_srv_config_step
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hcbi_utility.seq_srv_config_step OWNER TO hcbi_utility;

--
-- TOC entry 423 (class 1259 OID 395992229)
-- Name: seq_srv_metadata_copy_src; Type: SEQUENCE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE SEQUENCE hcbi_utility.seq_srv_metadata_copy_src
    START WITH 1
    INCREMENT BY 1
    MINVALUE 0
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hcbi_utility.seq_srv_metadata_copy_src OWNER TO hcbi_utility;

--
-- TOC entry 424 (class 1259 OID 395992230)
-- Name: seq_srv_svecchiamento_fct; Type: SEQUENCE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE SEQUENCE hcbi_utility.seq_srv_svecchiamento_fct
    START WITH 54
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hcbi_utility.seq_srv_svecchiamento_fct OWNER TO hcbi_utility;

--
-- TOC entry 425 (class 1259 OID 395992231)
-- Name: srv_config_chain; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.srv_config_chain (
    id_chain bigint NOT NULL,
    ds_chain_name character varying(500) NOT NULL,
    tx_description character varying(4000),
    fl_active character(1) DEFAULT 'Y'::bpchar,
    dt_creation timestamp without time zone DEFAULT clock_timestamp() NOT NULL,
    tx_creation_by character varying(4000) NOT NULL,
    dt_update timestamp without time zone NOT NULL,
    tx_update_by character varying(4000) NOT NULL,
    CONSTRAINT chk_srv_config_chain_active CHECK ((fl_active = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE hcbi_utility.srv_config_chain OWNER TO hcbi_utility;

--
-- TOC entry 5588 (class 0 OID 0)
-- Dependencies: 425
-- Name: TABLE srv_config_chain; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.srv_config_chain IS 'Tabella di servizio, controlli, configurazioni Config Chain';


--
-- TOC entry 5589 (class 0 OID 0)
-- Dependencies: 425
-- Name: COLUMN srv_config_chain.id_chain; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_config_chain.id_chain IS 'ID di sistema Chain';


--
-- TOC entry 5590 (class 0 OID 0)
-- Dependencies: 425
-- Name: COLUMN srv_config_chain.ds_chain_name; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_config_chain.ds_chain_name IS 'Descrizione Chain Name';


--
-- TOC entry 5591 (class 0 OID 0)
-- Dependencies: 425
-- Name: COLUMN srv_config_chain.tx_description; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_config_chain.tx_description IS 'Descrizione Catena';


--
-- TOC entry 426 (class 1259 OID 395992239)
-- Name: srv_config_step; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.srv_config_step (
    id_step bigint DEFAULT nextval('hcbi_utility.seq_srv_config_step'::regclass) NOT NULL,
    id_chain bigint NOT NULL,
    ds_step_name character varying(100) NOT NULL,
    ds_package_name character varying(100) NOT NULL,
    nr_step_order bigint NOT NULL,
    id_dependency_step bigint,
    nr_retry_count bigint DEFAULT 0,
    fl_blocking character(1) DEFAULT 'Y'::bpchar,
    fl_active character(1) DEFAULT 'Y'::bpchar,
    dt_creation timestamp without time zone DEFAULT clock_timestamp() NOT NULL,
    tx_creation_by character varying(4000) NOT NULL,
    dt_update timestamp without time zone NOT NULL,
    tx_update_by character varying(4000) NOT NULL,
    CONSTRAINT chk_srv_config_step_active CHECK ((fl_active = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT chk_srv_config_step_blocking CHECK ((fl_blocking = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT chk_srv_config_step_retry CHECK ((nr_retry_count >= 0))
);


ALTER TABLE hcbi_utility.srv_config_step OWNER TO hcbi_utility;

--
-- TOC entry 5593 (class 0 OID 0)
-- Dependencies: 426
-- Name: TABLE srv_config_step; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.srv_config_step IS 'Tabella di servizio, controlli, configurazioni Config Step';


--
-- TOC entry 427 (class 1259 OID 395992252)
-- Name: srv_metadata_copy_src; Type: TABLE; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE TABLE hcbi_utility.srv_metadata_copy_src (
    id_config bigint DEFAULT nextval('hcbi_utility.seq_srv_metadata_copy_src'::regclass) NOT NULL,
    id_chain bigint NOT NULL,
    ds_source_name text NOT NULL,
    ds_target_tmp_table text NOT NULL,
    fl_active character(1) DEFAULT 'Y'::bpchar NOT NULL,
    dt_creation timestamp without time zone NOT NULL,
    tx_creation_by text NOT NULL,
    dt_update timestamp without time zone NOT NULL,
    tx_update_by text NOT NULL
);


ALTER TABLE hcbi_utility.srv_metadata_copy_src OWNER TO hcbi_utility;

--
-- TOC entry 5595 (class 0 OID 0)
-- Dependencies: 427
-- Name: TABLE srv_metadata_copy_src; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON TABLE hcbi_utility.srv_metadata_copy_src IS 'Tabella di servizio, controlli, configurazioni Metadata Copy Src';


--
-- TOC entry 5596 (class 0 OID 0)
-- Dependencies: 427
-- Name: COLUMN srv_metadata_copy_src.id_config; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_metadata_copy_src.id_config IS 'ID di sistema Config';


--
-- TOC entry 5597 (class 0 OID 0)
-- Dependencies: 427
-- Name: COLUMN srv_metadata_copy_src.id_chain; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_metadata_copy_src.id_chain IS 'ID di sistema Chain';


--
-- TOC entry 5598 (class 0 OID 0)
-- Dependencies: 427
-- Name: COLUMN srv_metadata_copy_src.ds_source_name; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_metadata_copy_src.ds_source_name IS 'Descrizione Source Name';


--
-- TOC entry 5599 (class 0 OID 0)
-- Dependencies: 427
-- Name: COLUMN srv_metadata_copy_src.ds_target_tmp_table; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_metadata_copy_src.ds_target_tmp_table IS 'Descrizione Target Tmp Table';


--
-- TOC entry 5600 (class 0 OID 0)
-- Dependencies: 427
-- Name: COLUMN srv_metadata_copy_src.fl_active; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_metadata_copy_src.fl_active IS 'Flag Active';


--
-- TOC entry 5601 (class 0 OID 0)
-- Dependencies: 427
-- Name: COLUMN srv_metadata_copy_src.dt_creation; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_metadata_copy_src.dt_creation IS 'Data di creazione del record';


--
-- TOC entry 5602 (class 0 OID 0)
-- Dependencies: 427
-- Name: COLUMN srv_metadata_copy_src.tx_creation_by; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_metadata_copy_src.tx_creation_by IS 'Processo che ha creato il record';


--
-- TOC entry 5603 (class 0 OID 0)
-- Dependencies: 427
-- Name: COLUMN srv_metadata_copy_src.dt_update; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_metadata_copy_src.dt_update IS 'Data di aggiornamento del record';


--
-- TOC entry 5604 (class 0 OID 0)
-- Dependencies: 427
-- Name: COLUMN srv_metadata_copy_src.tx_update_by; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON COLUMN hcbi_utility.srv_metadata_copy_src.tx_update_by IS 'Processo che ha aggiornato il record';


--
-- TOC entry 428 (class 1259 OID 395992259)
-- Name: v_check_step_da_ottimizzare; Type: VIEW; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE VIEW hcbi_utility.v_check_step_da_ottimizzare AS
 SELECT id_chain,
    ds_chain_name,
    ds_step_name,
    dt_start,
    dt_end,
    elapsed_minutes
   FROM ( SELECT a.id_log,
            a.id_chain_log,
            a.id_chain,
            a.id_step,
            a.ds_step_name,
            a.dt_start,
            a.dt_end,
            (EXTRACT(epoch FROM (a.dt_end - a.dt_start)) / (60)::numeric) AS elapsed_minutes,
            a.ds_status,
            a.tx_error_message,
            a.nr_rec_selected,
            a.nr_rec_inserted,
            a.nr_rec_updated,
            a.nr_rec_deleted,
            a.nr_rec_errors,
            max(a.id_chain_log) OVER (PARTITION BY a.id_chain) AS last_run,
            b.ds_chain_name
           FROM (hcbi_utility.log_step a
             JOIN hcbi_utility.srv_config_chain b ON ((a.id_chain = b.id_chain)))) x
  WHERE ((id_chain_log = last_run) AND (elapsed_minutes > (1)::numeric));


ALTER VIEW hcbi_utility.v_check_step_da_ottimizzare OWNER TO hcbi_utility;

--
-- TOC entry 429 (class 1259 OID 395992264)
-- Name: v_log_chain_last_run; Type: VIEW; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE VIEW hcbi_utility.v_log_chain_last_run AS
 SELECT id_chain,
    id_log_last_run,
    ds_chain_name,
    dt_start,
    dt_end,
    (EXTRACT(epoch FROM (dt_end - dt_start)) / (60)::numeric) AS elapsed_minutes,
    ds_status,
    tx_error_message
   FROM ( SELECT b.id_chain,
            b.ds_chain_name,
            a.dt_start,
            a.dt_end,
            a.ds_status,
            a.tx_error_message,
            a.id_log,
            max(a.id_log) OVER (PARTITION BY a.id_chain) AS id_log_last_run
           FROM (hcbi_utility.log_chain a
             JOIN hcbi_utility.srv_config_chain b ON ((a.id_chain = b.id_chain)))) x
  WHERE (id_log = id_log_last_run);


ALTER VIEW hcbi_utility.v_log_chain_last_run OWNER TO hcbi_utility;

--
-- TOC entry 431 (class 1259 OID 396106668)
-- Name: vw_etl_frontiere_config; Type: VIEW; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE VIEW hcbi_utility.vw_etl_frontiere_config AS
 SELECT frontiera_code,
    description,
    execution_order,
    source_service_code,
    source_query,
    target_schema,
    target_table,
    truncate_before_load
   FROM hcbi_utility.etl_frontiere_config c
  WHERE (enabled = true);


ALTER VIEW hcbi_utility.vw_etl_frontiere_config OWNER TO hcbi_utility;

--
-- TOC entry 5608 (class 0 OID 0)
-- Dependencies: 431
-- Name: VIEW vw_etl_frontiere_config; Type: COMMENT; Schema: hcbi_utility; Owner: hcbi_utility
--

COMMENT ON VIEW hcbi_utility.vw_etl_frontiere_config IS 'Configurazioni attive lette dal runner NiFi, ordinate dalla query chiamante.';


--
-- TOC entry 5507 (class 0 OID 395992207)
-- Dependencies: 417
-- Data for Name: cfg_connections; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.cfg_connections (conn_name, conn_string) FROM stdin;
LOOPBACK_DBLINK	dbname=hcbi user=hcbi_utility password=hcbi_utility host=192.168.248.135 port=5432
\.


--
-- TOC entry 5525 (class 0 OID 398901487)
-- Dependencies: 478
-- Data for Name: dwh_schedule; Type: TABLE DATA; Schema: hcbi_utility; Owner: postgres
--

COPY hcbi_utility.dwh_schedule (schedule_id, process_code, process_description, enabled, frequency_code, anchor_month, week_ordinal, weekday_iso, retry_days, last_success_at, last_success_period_start, last_attempt_at, last_attempt_status, last_error_message, created_at, updated_at) FROM stdin;
3	DWH_REFRESH_MONTHLY	Refresh DWH - mensile	f	MONTHLY	\N	1	1	6	\N	\N	\N	\N	\N	2026-10-28 15:52:27.161026+01	2026-10-28 15:52:27.161106+01
4	DWH_REFRESH_BIMONTHLY	Refresh DWH - bimestrale	f	BIMONTHLY	1	1	1	6	\N	\N	\N	\N	\N	2026-10-28 15:52:57.117275+01	2026-10-28 15:52:57.117445+01
5	DWH_REFRESH_QUARTERLY	Refresh DWH - trimestrale	f	QUARTERLY	1	1	1	6	\N	\N	\N	\N	\N	2026-10-28 15:53:26.473299+01	2026-10-28 15:53:26.473386+01
6	DWH_REFRESH_FOUR_MONTHLY	Refresh DWH - quadrimestrale	f	FOUR_MONTHLY	1	1	1	6	\N	\N	\N	\N	\N	2026-10-28 15:54:06.47432+01	2026-10-28 15:54:06.474389+01
7	DWH_REFRESH_SEMIANNUAL	Refresh DWH - semestrale	f	SEMIANNUAL	1	1	1	6	\N	\N	\N	\N	\N	2026-10-28 15:54:34.518014+01	2026-10-28 15:54:34.518053+01
8	DWH_REFRESH_ANNUAL	Refresh DWH - annuale	f	ANNUAL	1	1	1	6	\N	\N	\N	\N	\N	2026-10-28 15:55:02.28737+01	2026-10-28 15:55:02.287433+01
1	DWH_REFRESH_DAILY	Refresh DWH	t	DAILY	\N	\N	\N	\N	2026-11-05 10:14:42.901388+01	2026-11-05	2026-11-05 10:23:26.203291+01	SUCCESS	\N	2026-10-28 15:51:09.969349+01	2026-11-05 10:23:26.205098+01
2	DWH_REFRESH_WEEKLY	Refresh DWH - settimanale	f	WEEKLY	\N	\N	1	6	2026-11-03 08:16:50.503979+01	2026-11-02	2026-11-05 10:10:10.318148+01	SUCCESS	\N	2026-10-28 15:51:14.547256+01	2026-11-05 10:14:05.929695+01
\.


--
-- TOC entry 5526 (class 0 OID 398901507)
-- Dependencies: 479
-- Data for Name: dwh_schedule_run; Type: TABLE DATA; Schema: hcbi_utility; Owner: postgres
--

COPY hcbi_utility.dwh_schedule_run (run_id, schedule_id, process_code, planned_date, trigger_source, requested_by, period_start, period_end, started_at, finished_at, status, return_code, duration_ms, error_message) FROM stdin;
\.


--
-- TOC entry 5523 (class 0 OID 396127220)
-- Dependencies: 437
-- Data for Name: etl_dwh_refresh_run; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.etl_dwh_refresh_run (run_id, execution_uuid, chain_id, started_at, ended_at, status, error_message) FROM stdin;
\.


--
-- TOC entry 5530 (class 0 OID 399416116)
-- Dependencies: 483
-- Data for Name: etl_execution_log_event; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.etl_execution_log_event (event_id, ingestion_id, source_code, source_path, source_device, source_inode, byte_offset_start, byte_offset_end, source_line_start, source_line_end, event_timestamp, log_level, event_execution_uuid, manifest_execution_uuid, event_scheduler_run_id, manifest_scheduler_run_id, chain_id, process_name, cycle_exit_code, correlation_status, parse_status, is_redacted, message_text, event_hash, ingested_at) FROM stdin;
\.


--
-- TOC entry 5528 (class 0 OID 399416087)
-- Dependencies: 481
-- Data for Name: etl_execution_log_ingestion; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.etl_execution_log_ingestion (ingestion_id, source_code, source_path, source_device, source_inode, offset_start, offset_end, manifest_execution_uuid, scheduler_run_id, cycle_result, cycle_exit_code, started_at, finished_at, status, events_read, events_inserted, events_duplicate, events_rejected, bytes_read, error_code, error_message, retry_of_ingestion_id) FROM stdin;
\.


--
-- TOC entry 5518 (class 0 OID 396106603)
-- Dependencies: 430
-- Data for Name: etl_frontiere_config; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.etl_frontiere_config (frontiera_code, description, enabled, execution_order, source_service_code, source_query, target_schema, target_table, truncate_before_load, created_at, created_by, updated_at, updated_by) FROM stdin;
FRONTIERA_ANAG_UNITA_MISURA	Anagrafica unita di misura	f	70	RASOP	SELECT\n    um.codice,\n    um.descrizione,\n    um.decimali::character varying(100) AS decimali,\n    um.id::character varying(100) AS id,\n    um.last_update,\n    um.data_fine_validita\nFROM public.unita_misura AS um\nORDER BY um.codice;\n	hcbi_ras	frontiera_anag_unita_misura	t	2026-10-15 08:14:09.165462+02	postgres	2026-10-15 08:14:09.165462+02	postgres
FRONTIERA_ANAG_LIVELLO_CODIFICA	Anagrafica livelli di codifica	f	40	RASOP	SELECT\n    lc.id::character varying(100) AS id,\n    lc.nome,\n    lc.plurale\nFROM public.livelli_codifica AS lc\nORDER BY lc.id;\n	hcbi_ras	frontiera_anag_livello_codifica	t	2026-10-15 08:14:09.165304+02	postgres	2026-10-15 08:14:09.165304+02	postgres
FRONTIERA_ARTICOLI_INFORMATORI	Associazione articoli e informatori	f	100	RASOP	SELECT\n    ai.id_informatore::character varying(100) AS id_informatore,\n    ai.codice_articolo,\n    ai.anno::character varying(100) AS anno,\n    CASE WHEN ai.escluso IS TRUE THEN '1'\n         WHEN ai.escluso IS FALSE THEN '0'\n    END::character varying(20) AS escluso,\n    ai.addendum::character varying(20) AS addendum,\n    ai.id::character varying(100) AS id,\n    ai.user_id::character varying(100) AS user_id\nFROM public.articoli_informatori AS ai\nORDER BY ai.id;\n	hcbi_ras	frontiera_articoli_informatori	t	2026-10-15 08:14:09.166407+02	postgres	2026-10-15 08:14:09.166407+02	postgres
FRONTIERA_ANAG_MACRO_GRUPPO	Anagrafica macro gruppi	t	50	RASOP	SELECT\r\n    mg.id::character varying(100) AS id,\r\n    mg.nome,\r\n    mg.plurale\r\nFROM public.macro_gruppi AS mg\r\nORDER BY mg.id;\r\n	hcbi_ras	frontiera_anag_macro_gruppo	t	2026-10-15 08:14:09.165399+02	postgres	2026-10-15 08:14:09.1654+02	postgres
FRONTIERA_ANNI	Anagrafica anni	f	90	RASOP	SELECT\n    a.anno::character varying(100) AS anno,\n    a.addendum::character varying(20) AS addendum,\n    a.addendum_name,\n    CASE WHEN a.scostamento_1_visibile IS TRUE THEN '1'\n         WHEN a.scostamento_1_visibile IS FALSE THEN '0'\n    END::character varying(20) AS scostamento_1_visibile,\n    CASE WHEN a.scostamento_2_visibile IS TRUE THEN '1'\n         WHEN a.scostamento_2_visibile IS FALSE THEN '0'\n    END::character varying(20) AS scostamento_2_visibile,\n    CASE WHEN a.scostamento_3_visibile IS TRUE THEN '1'\n         WHEN a.scostamento_3_visibile IS FALSE THEN '0'\n    END::character varying(20) AS scostamento_3_visibile,\n    CASE WHEN a.scostamento_4_visibile IS TRUE THEN '1'\n         WHEN a.scostamento_4_visibile IS FALSE THEN '0'\n    END::character varying(20) AS scostamento_4_visibile,\n    a.spese_generali::character varying(100) AS spese_generali,\n    a.utile_impresa::character varying(100) AS utile_impresa,\n    a.llpp_homepage_title,\n    a.llpp_homepage_description,\n    a.di_cui_analisi::character varying(100) AS di_cui_analisi,\n    CASE WHEN a.pubblicazione_regionale IS TRUE THEN '1'\n         WHEN a.pubblicazione_regionale IS FALSE THEN '0'\n    END::character varying(20) AS pubblicazione_regionale,\n    a.llpp_homepage_title_de,\n    a.llpp_homepage_description_de,\n    CASE WHEN a.scostamento_5_visibile IS TRUE THEN '1'\n         WHEN a.scostamento_5_visibile IS FALSE THEN '0'\n    END::character varying(20) AS scostamento_5_visibile,\n    a.preferenze_esportazione::text AS preferenze_esportazione,\n    a.id::character varying(100) AS id,\n    a.impostazioni_prezzi::text AS impostazioni_prezzi,\n    a.mostra_annotazioni::character varying(20) AS mostra_annotazioni,\n    a.mostra_struttura_analisi::character varying(20) AS mostra_struttura_analisi,\n    CASE WHEN a.is_errata_corrige IS TRUE THEN '1'\n         WHEN a.is_errata_corrige IS FALSE THEN '0'\n    END::character varying(20) AS is_errata_corrige,\n    a.mostra_cam::character varying(20) AS mostra_cam\nFROM public.anni AS a\nORDER BY a.anno;\n	hcbi_ras	frontiera_anni	t	2026-10-15 08:14:09.165528+02	postgres	2026-10-15 08:14:09.165528+02	postgres
FRONTIERA_PREZZI_RILEVATI	Prezzi rilevati	f	120	RASOP	SELECT\n    pr.codice,\n    pr.anno::character varying(100) AS anno,\n    pr.provincia::character varying(100) AS provincia,\n    pr.informatore::character varying(100) AS informatore,\n    pr.rilevatore::character varying(100) AS rilevatore,\n    pr.prezzo::character varying(100) AS prezzo,\n    pr.data_inserimento,\n    pr.nascosto::character varying(20) AS nascosto,\n    pr.ribaltato_da_anno::character varying(100) AS ribaltato_da_anno,\n    pr.addendum::character varying(20) AS addendum,\n    pr.ribaltato_da_addendum::character varying(100) AS ribaltato_da_addendum,\n    pr.last_update\nFROM public.prezzi_rilevati AS pr\nORDER BY pr.codice, pr.anno, pr.provincia;\n	hcbi_ras	frontiera_prezzi_rilevati	t	2026-10-15 08:14:09.166487+02	postgres	2026-10-15 08:14:09.166487+02	postgres
FRONTIERA_ANAG_UTENTI	Anagrafica utenti	f	80	RASOP	SELECT\n    u.user_id::character varying(100) AS user_id,\n    u.username,\n    u.email,\n    u.display_name,\n    u.state::character varying(20) AS state,\n    u.usertype\nFROM public."user" AS u\nORDER BY u.user_id;\n	hcbi_ras	frontiera_anag_utenti	t	2026-10-15 08:14:09.165498+02	postgres	2026-10-15 08:14:09.165498+02	postgres
FRONTIERA_PUBBLICAZIONE_ANALISI	Pubblicazione analisi	f	140	RASOP	 SELECT\r\n    pa.anno::character varying(100) AS anno,\r\n    pa.codice_analisi,\r\n    pa.quantita::character varying(100) AS quantita,\r\n    pa.codice_elemento,\r\n    pa.addendum::character varying(20) AS addendum,\r\n    pa.id::character varying(100) AS id,\r\n    pa.id_categoria::character varying(20) AS id_categoria,\r\n        ROW_NUMBER() OVER (\r\n        PARTITION BY\r\n            pa.anno,\r\n            pa.codice_analisi,\r\n            pa.codice_elemento,\r\n            pa.addendum\r\n        ORDER BY\r\n            pa.id ASC\r\n    ) AS nr_riga\r\nFROM public.pubblicazione_analisi AS pa\r\nORDER BY     pa.id,\r\n    pa.anno,\r\n    pa.codice_analisi,\r\n    pa.codice_elemento,\r\n    pa.addendum,\r\n    nr_riga;\r\n	hcbi_ras	frontiera_pubblicazione_analisi	t	2026-10-15 08:14:09.169155+02	postgres	2026-10-15 08:14:09.169155+02	postgres
FRONTIERA_PUBBLICAZIONE_ALBERO	Pubblicazione albero	f	130	RASOP	SELECT\n    pa.anno::character varying(100) AS anno,\n    pa.provincia::character varying(100) AS provincia,\n    pa.codice,\n    pa.descrizione,\n    pa.prezzo::character varying(100) AS prezzo,\n    pa.idum::character varying(100) AS idum,\n    pa.isanalisi::character varying(20) AS isanalisi,\n    pa.isincidenza::character varying(20) AS isincidenza,\n    pa.addendum::character varying(20) AS addendum,\n    pa.scostamento::character varying(100) AS scostamento,\n    pa.scostamento_con_spese::character varying(100) AS scostamento_con_spese,\n    pa.is_nuovo_codice::character varying(20) AS is_nuovo_codice,\n    pa.is_prezzo_modificato::character varying(20) AS is_prezzo_modificato,\n    pa.is_prezzo_con_spese_modificato::character varying(20)\n        AS is_prezzo_con_spese_modificato,\n    pa.is_analisi_modificata::character varying(20) AS is_analisi_modificata,\n    pa.is_descrizione_modificata::character varying(20)\n        AS is_descrizione_modificata,\n    pa.is_uinta_misura_modificata::character varying(20)\n        AS is_uinta_misura_modificata,\n    pa.is_spese_generali_modificate::character varying(20)\n        AS is_spese_generali_modificate,\n    pa.is_utili_impresa_modificati::character varying(20)\n        AS is_utili_impresa_modificati,\n    pa.is_oneri_sicurezza_modificati::character varying(20)\n        AS is_oneri_sicurezza_modificati,\n    pa.descrizione_de,\n    pa.is_ufficiale::character varying(20) AS is_ufficiale,\n    pa.id_categoria::character varying(20) AS id_categoria,\n    pa.nome,\n    pa.nome_de,\n    pa.is_nome_modificato::character varying(20) AS is_nome_modificato,\n    pa.link_cam,\n    pa.annotazione,\n    pa.annotazione_de,\n    pa.id::character varying(100) AS id,\n    CASE WHEN pa.esporta_come_articolo IS TRUE THEN '1'\n         WHEN pa.esporta_come_articolo IS FALSE THEN '0'\n    END::character varying(20) AS esporta_come_articolo,\n    CASE WHEN pa.escludi_manodopera IS TRUE THEN '1'\n         WHEN pa.escludi_manodopera IS FALSE THEN '0'\n    END::character varying(20) AS escludi_manodopera,\n    CASE WHEN pa.mostra_struttura_analisi IS TRUE THEN '1'\n         WHEN pa.mostra_struttura_analisi IS FALSE THEN '0'\n    END::character varying(20) AS mostra_struttura_analisi,\n    pa.macro_gruppo::character varying(20) AS macro_gruppo,\n    pa.is_cam::character varying(20) AS is_cam\nFROM public.pubblicazione_albero AS pa\nORDER BY pa.anno, pa.provincia, pa.codice;\n	hcbi_ras	frontiera_pubblicazione_albero	t	2026-10-15 08:14:09.166513+02	postgres	2026-10-15 08:14:09.166513+02	postgres
FRONTIERA_ANAG_INFORMATORI	Anagrafica informatori	f	30	RASOP	SELECT\n    i.id::character varying(100) AS id,\n    i.ragione_sociale,\n    i.p_iva,\n    i.codice_ateco_2002,\n    i.indirizzo_sede_legale,\n    i.cap_sede_legale,\n    i.citta_sede_legale,\n    i.provincia_sede_legale,\n    i.indirizzo_sede_operativa,\n    i.cap_sede_operativa,\n    i.citta_sede_operativa,\n    i.provincia_sede_operativa,\n    i.contatti,\n    i.stato::character varying(20) AS stato,\n    i.note,\n    i.stato_attivita,\n    i.codice_fiscale,\n    i.anno::character varying(100) AS anno,\n    i.last_update::character varying(100) AS last_update,\n    i.nazione,\n    i.addendum::character varying(20) AS addendum,\n    i.escludi_invio_mail_assoc_listino_completa::character varying(20)\n        AS escludi_invio_mail_assoc_listino_completa\nFROM public.informatori AS i\nORDER BY i.id;\n	hcbi_ras	frontiera_anag_informatori	t	2026-10-15 08:14:09.164876+02	postgres	2026-10-15 08:14:09.164876+02	postgres
FRONTIERA_PUBBLICAZIONE_ARTICOLI	Pubblicazione articoli	f	150	RASOP	SELECT\n    pa.provincia::character varying(100) AS provincia,\n    pa.anno::character varying(100) AS anno,\n    pa.codice_completo,\n    pa.um,\n    pa.prezzo::character varying(100) AS prezzo,\n    pa.prezan::character varying(100) AS prezan,\n    pa.percsp::character varying(100) AS percsp,\n    pa.percutil::character varying(100) AS percutil,\n    pa.sicur::character varying(100) AS sicur,\n    pa.percman::character varying(100) AS percman,\n    pa.perconeri::character varying(100) AS perconeri,\n    pa.isanalisi::character varying(20) AS isanalisi,\n    pa.prezman::character varying(100) AS prezman,\n    pa.addendum::character varying(20) AS addendum,\n    pa.codice,\n    pa.codice_1,\n    pa.codice_2,\n    pa.codice_3,\n    pa.codice_4,\n    pa.codice_5,\n    pa.um_de,\n    pa.id_categoria::character varying(20) AS id_categoria,\n    pa.is_minuteria::character varying(20) AS is_minuteria,\n    pa.id::character varying(100) AS id,\n    null AS percman_diretta,\n    null AS prezman_diretta,\n    pa.ifc_scaricabile::character varying(20) AS ifc_scaricabile,\n    pa.macro_gruppo::character varying(20) AS macro_gruppo,\n    pa.spese::character varying(100) AS spese,\n    pa.utili::character varying(100) AS utili\nFROM public.pubblicazione_articoli AS pa\nORDER BY pa.provincia, pa.anno, pa.codice_completo;	hcbi_ras	frontiera_pubblicazione_articoli	t	2026-10-15 08:14:09.169707+02	postgres	2026-10-15 08:14:09.169707+02	postgres
FRONTIERA_ANAG_AREA_VASTA	Anagrafica area vasta	f	10	RASOP	\nSELECT\n    av.id::character varying(100) AS id,\n    av.nome::character varying(100) AS nome,\n    av.anno::character varying(20) AS anno,\n    av.addendum::character varying(20) AS addendum\nFROM public.aree_vaste AS av\norder by av.anno,av.addendum,av.id;\n	hcbi_ras	frontiera_anag_area_vasta	t	2026-10-15 08:14:09.162+02	postgres	2026-10-15 08:14:09.162+02	postgres
FRONTIERA_ANAG_PROVINCIA	Anagrafica province	f	60	RASOP	SELECT\r\n    p.id::character varying(100) AS id,\r\n    p.provincia,\r\n    p.nome,\r\n    p.id_area_vasta::character varying(20) AS id_area_vasta,\r\n    p.provincia_principale_regionale::character varying(20)\r\n        AS provincia_principale_regionale,\r\n    p.provincia_principale_area_vasta::character varying(20)\r\n        AS provincia_principale_area_vasta,\r\n    p.anno::character varying(20) AS anno,\r\n    p.addendum::character varying(20) AS addendum\r\nFROM public.province AS p\r\norder by p.anno,p.addendum,p.provincia,p.id;\r\n	hcbi_ras	frontiera_anag_provincia	t	2026-10-15 08:14:09.165+02	postgres	2026-10-15 08:14:09.165+02	postgres
FRONTIERA_PREZZI_APPROVATI	Prezzi approvati	f	110	RASOP	SELECT\n    pa.codice,\n    pa.anno::character varying(100) AS anno,\n    pa.prezzo::character varying(100) AS prezzo,\n    pa.provincia::character varying(100) AS provincia,\n    pa.data_approvazione,\n    pa.addendum::character varying(20) AS addendum\nFROM public.prezzi_approvati AS pa\nORDER BY pa.codice, pa.anno, pa.provincia;\n	hcbi_ras	frontiera_prezzi_approvati	t	2026-10-15 08:14:09.166447+02	postgres	2026-10-15 08:14:09.166447+02	postgres
FRONTIERA_ANAG_ARTICOLO	Anagrafica articolo	f	20	RASOP	SELECT\n    a.id::character varying(100) AS id,\n    a.anno::character varying(100) AS anno,\n    a.codice::character varying(60) AS codice,\n    a.livello::character varying(20) AS livello,\n    a.nome,\n    a.descrizione,\n    a.eliminato::character varying(20) AS eliminato,\n    a.prezzo_regionale::character varying(20) AS prezzo_regionale,\n    a.unita_misura::character varying(100) AS unita_misura,\n    a.macro_gruppo::character varying(20) AS macro_gruppo,\n    a.spese_generali::character varying(100) AS spese_generali,\n    a.di_cui_analisi::character varying(100) AS di_cui_analisi,\n    a.utile_impresa::character varying(100) AS utile_impresa,\n    a.last_update,\n    a.analisi_approvata::character varying(20) AS analisi_approvata,\n    a.has_utile_impresa::character varying(20) AS has_utile_impresa,\n    a.analisi_pubblicata::character varying(20) AS analisi_pubblicata,\n    a.addendum::character varying(20) AS addendum,\n    a.is_analisi::character varying(20) AS is_analisi,\n    a.is_cam::character varying(20) AS is_cam,\n    a.is_ufficiale::character varying(20) AS is_ufficiale,\n    a.id_categoria::character varying(100) AS id_categoria,\n    a.is_manodopera::character varying(20) AS is_manodopera,\n    a.codice_lev1,\n    a.codice_lev2,\n    a.codice_lev3,\n    a.codice_lev4,\n    a.codice_lev5,\n    a.is_minuteria::character varying(20) AS is_minuteria,\n    a.percentuale_aumento::character varying(100) AS percentuale_aumento,\n    a.annotazione,\n    CASE WHEN a.esporta_come_articolo IS TRUE THEN '1'\n         WHEN a.esporta_come_articolo IS FALSE THEN '0'\n    END::character varying(20) AS esporta_come_articolo,\n    CASE WHEN a.escludi_manodopera IS TRUE THEN '1'\n         WHEN a.escludi_manodopera IS FALSE THEN '0'\n    END::character varying(20) AS escludi_manodopera\nFROM public.articoli AS a\nORDER BY a.id;\n	hcbi_ras	frontiera_anag_articolo	t	2026-10-15 08:14:09.164707+02	postgres	2026-10-15 08:14:09.164707+02	postgres
\.


--
-- TOC entry 5521 (class 0 OID 396106719)
-- Dependencies: 435
-- Data for Name: etl_frontiere_execution_lock; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.etl_frontiere_execution_lock (frontiera_code, run_id, acquired_at, acquired_by) FROM stdin;
\.


--
-- TOC entry 5520 (class 0 OID 396106696)
-- Dependencies: 434
-- Data for Name: etl_frontiere_run; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.etl_frontiere_run (run_id, frontiera_code, started_at, ended_at, status, rows_read, rows_written, error_message, warning_message, nifi_flowfile_uuid) FROM stdin;
\.


--
-- TOC entry 5509 (class 0 OID 395992213)
-- Dependencies: 419
-- Data for Name: log_chain; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.log_chain (id_log, id_chain, dt_start, dt_end, ds_status, tx_error_message, dt_creation, tx_creation_by, dt_update, tx_update_by, etl_execution_uuid) FROM stdin;
\.


--
-- TOC entry 5511 (class 0 OID 395992221)
-- Dependencies: 421
-- Data for Name: log_step; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.log_step (id_log, id_chain_log, id_chain, id_step, ds_step_name, dt_start, dt_end, ds_status, tx_error_message, nr_rec_selected, nr_rec_inserted, nr_rec_updated, nr_rec_deleted, nr_rec_errors, dt_creation, tx_creation_by, dt_update, tx_update_by) FROM stdin;
\.


--
-- TOC entry 5515 (class 0 OID 395992231)
-- Dependencies: 425
-- Data for Name: srv_config_chain; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.srv_config_chain (id_chain, ds_chain_name, tx_description, fl_active, dt_creation, tx_creation_by, dt_update, tx_update_by) FROM stdin;
1	hcbi_ras Full ras	Catena full per modulo PS	Y	2025-03-04 13:17:21.785	ADMIN	2025-03-04 13:17:21.785	ADMIN
\.


--
-- TOC entry 5516 (class 0 OID 395992239)
-- Dependencies: 426
-- Data for Name: srv_config_step; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.srv_config_step (id_step, id_chain, ds_step_name, ds_package_name, nr_step_order, id_dependency_step, nr_retry_count, fl_blocking, fl_active, dt_creation, tx_creation_by, dt_update, tx_update_by) FROM stdin;
67	1	ras-Popolamento tabella fct_pubblicazione_articoli_fascia_prezzo	hcbi_ras.pkg_fct_pub_art_fascia_prezzo	2121	\N	5	Y	Y	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
6	1	ras-Popolamento tabella stg_pubblicazione_analisi	hcbi_ras.pkg_stg_pubblicazione_analisi	150	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
7	1	ras-Popolamento tabella dwh_pubblicazione_analisi	hcbi_ras.pkg_dwh_pubblicazione_analisi	160	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
4	1	ras-Popolamento tabella stg_pubblicazione_albero	hcbi_ras.pkg_stg_pubblicazione_albero	130	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
5	1	ras-Popolamento tabella dwh_pubblicazione_albero	hcbi_ras.pkg_dwh_pubblicazione_albero	140	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
8	1	ras-Popolamento tabella stg_anag_informatori	hcbi_ras.pkg_stg_anag_informatori	170	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
9	1	ras-Popolamento tabella dwh_anag_informatori	hcbi_ras.pkg_dwh_anag_informatori	180	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
10	1	ras-Popolamento tabella stg_anag_provincia	hcbi_ras.pkg_stg_anag_provincia	190	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
11	1	ras-Popolamento tabella dwh_anag_provincia	hcbi_ras.pkg_dwh_anag_provincia	200	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
12	1	ras-Popolamento tabella stg_anag_area_vasta	hcbi_ras.pkg_stg_anag_area_vasta	210	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
13	1	ras-Popolamento tabella dwh_anag_area_vasta	hcbi_ras.pkg_dwh_anag_area_vasta	220	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
14	1	ras-Popolamento tabella stg_anag_versione	hcbi_ras.pkg_stg_anag_versione	230	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
1	1	ras Creazione tabelle SRC_TMP definite in SRV_METADATA_COPY_SRC per la chain	hcbi_ras.pkg_copy_data_src_dynamic	100	\N	5	Y	Y	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
15	1	ras-Popolamento tabella dwh_anag_versione	hcbi_ras.pkg_dwh_anag_versione	240	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
16	1	ras-Popolamento tabella stg_anag_utenti	hcbi_ras.pkg_stg_anag_utenti	250	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
17	1	ras-Popolamento tabella dwh_anag_utenti	hcbi_ras.pkg_dwh_anag_utenti	260	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
20	1	ras-Popolamento tabella stg_anag_tipologia	hcbi_ras.pkg_stg_anag_tipologia	281	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
21	1	ras-Popolamento tabella dwh_anag_tipologia	hcbi_ras.pkg_dwh_anag_tipologia	282	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
22	1	ras-Popolamento tabella stg_anag_capitolo	hcbi_ras.pkg_stg_anag_capitolo	283	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
23	1	ras-Popolamento tabella dwh_anag_capitolo	hcbi_ras.pkg_dwh_anag_capitolo	284	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
24	1	ras-Popolamento tabella stg_anag_sottocapitolo	hcbi_ras.pkg_stg_anag_sottocapitolo	285	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
25	1	ras-Popolamento tabella dwh_anag_sottocapitolo	hcbi_ras.pkg_dwh_anag_sottocapitolo	286	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
26	1	ras-Popolamento tabella stg_anag_tipo_utente	hcbi_ras.pkg_stg_anag_tipo_utente	261	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
27	1	ras-Popolamento tabella dwh_anag_tipo_utente	hcbi_ras.pkg_dwh_anag_tipo_utente	262	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
28	1	ras-Popolamento tabella dim_area_vasta	hcbi_ras.pkg_dim_area_vasta	1100	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
29	1	ras-Popolamento tabella dim_provincia	hcbi_ras.pkg_dim_provincia	1110	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
33	1	ras-Popolamento tabella dim_utenti	hcbi_ras.pkg_dim_utenti	1130	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
34	1	ras-Popolamento tabella dim_versione	hcbi_ras.pkg_dim_versione	1140	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
35	1	ras-Popolamento tabella dim_tipologia	hcbi_ras.pkg_dim_tipologia	1150	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
36	1	ras-Popolamento tabella dim_capitolo	hcbi_ras.pkg_dim_capitolo	1160	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
37	1	ras-Popolamento tabella dim_sottocapitolo	hcbi_ras.pkg_dim_sottocapitolo	1170	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
38	1	ras-Popolamento tabella stg_anag_livello_codifica	hcbi_ras.pkg_stg_anag_livello_codifica	310	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
39	1	ras-Popolamento tabella dwh_anag_livello_codifica	hcbi_ras.pkg_dwh_anag_livello_codifica	320	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
40	1	ras-Popolamento tabella dim_livello_codifica	hcbi_ras.pkg_dim_livello_codifica	1180	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
41	1	ras-Popolamento tabella stg_anag_macro_gruppo	hcbi_ras.pkg_stg_anag_macro_gruppo	330	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
42	1	ras-Popolamento tabella dwh_anag_macro_gruppo	hcbi_ras.pkg_dwh_anag_macro_gruppo	340	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
43	1	ras-Popolamento tabella dim_macro_gruppo	hcbi_ras.pkg_dim_macro_gruppo	1190	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
44	1	ras-Popolamento tabella stg_anag_ateco_2002	hcbi_ras.pkg_stg_anag_ateco_2002	350	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
45	1	ras-Popolamento tabella dwh_anag_ateco_2002	hcbi_ras.pkg_dwh_anag_ateco_2002	360	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
46	1	ras-Popolamento tabella dim_ateco_2002	hcbi_ras.pkg_dim_ateco_2002	1200	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
47	1	ras-Popolamento tabella dim_informatori	hcbi_ras.pkg_dim_informatori	1210	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
31	1	ras-Popolamento tabella dwh_anag_unita_misura	hcbi_ras.pkg_dwh_anag_unita_misura	300	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
32	1	ras-Popolamento tabella dim_unita_misura	hcbi_ras.pkg_dim_unita_misura	1120	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
52	1	ras-Popolamento tabella stg_prezzi_rilevati	hcbi_ras.pkg_stg_prezzi_rilevati	290	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
53	1	ras-Popolamento tabella dwh_prezzi_rilevati	hcbi_ras.pkg_dwh_prezzi_rilevati	300	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
55	1	ras-Popolamento tabella stg_prezzi_approvati	hcbi_ras.pkg_stg_prezzi_approvati	310	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
56	1	ras-Popolamento tabella dwh_prezzi_approvati	hcbi_ras.pkg_dwh_prezzi_approvati	320	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
57	1	ras-Popolamento tabella fct_prezzi_approvati	hcbi_ras.pkg_fct_prezzi_approvati	2140	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
58	1	ras-Popolamento tabella stg_articoli_informatori	hcbi_ras.pkg_stg_articoli_informatori	330	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
59	1	ras-Popolamento tabella dwh_articoli_informatori	hcbi_ras.pkg_dwh_articoli_informatori	340	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
60	1	ras-Popolamento tabella fct_articoli_informatori	hcbi_ras.pkg_fct_articoli_informatori	2150	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
61	1	ras-Popolamento tabella stg_firenze_analisi	hcbi_ras.pkg_stg_firenze_analisi	350	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
62	1	ras-Popolamento tabella dwh_firenze_analisi	hcbi_ras.pkg_dwh_firenze_analisi	360	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
54	1	ras-Popolamento tabella fct_prezzi_rilevati	hcbi_ras.pkg_fct_prezzi_rilevati	2130	\N	5	Y	Y	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
30	1	ras-Popolamento tabella stg_anag_unita_misura	hcbi_ras.pkg_stg_anag_unita_misura	290	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
50	1	ras-Popolamento tabella fct_pubblicazione_analisi	hcbi_ras.pkg_fct_pubblicazione_analisi	2110	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
49	1	ras-Popolamento tabella fct_pubblicazione_albero	hcbi_ras.pkg_fct_pubblicazione_albero	2100	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
63	1	ras-Popolamento tabella stg_firenze_articoli	hcbi_ras.pkg_stg_firenze_articoli	370	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
64	1	ras-Popolamento tabella dwh_firenze_articoli	hcbi_ras.pkg_dwh_firenze_articoli	380	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
65	1	ras-Popolamento tabella dim_firenze_articoli	hcbi_ras.pkg_dim_firenze_articoli	2160	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
18	1	ras-Popolamento tabella stg_anag_articolo	hcbi_ras.pkg_stg_anag_articolo	270	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
19	1	ras-Popolamento tabella dwh_anag_articolo	hcbi_ras.pkg_dwh_anag_articolo	280	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
48	1	ras-Popolamento tabella dim_articolo	hcbi_ras.pkg_dim_articolo	1220	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
2	1	ras-Popolamento tabella stg_pubblicazione_articoli	hcbi_ras.pkg_stg_pubblicazione_articoli	110	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
3	1	ras-Popolamento tabella dwh_pubblicazione_articoli	hcbi_ras.pkg_dwh_pubblicazione_articoli	120	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
51	1	ras-Popolamento tabella fct_pubblicazione_articoli	hcbi_ras.pkg_fct_pubblicazione_articoli	2120	\N	5	Y	N	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
66	1	ras-Popolamento tabella fct_firenze_analisi	hcbi_ras.pkg_fct_firenze_analisi	2170	\N	5	Y	Y	2025-12-19 10:30:00	ADMIN	2025-12-19 10:30:00	ADMIN
\.


--
-- TOC entry 5517 (class 0 OID 395992252)
-- Dependencies: 427
-- Data for Name: srv_metadata_copy_src; Type: TABLE DATA; Schema: hcbi_utility; Owner: hcbi_utility
--

COPY hcbi_utility.srv_metadata_copy_src (id_config, id_chain, ds_source_name, ds_target_tmp_table, fl_active, dt_creation, tx_creation_by, dt_update, tx_update_by) FROM stdin;
1	1	hcbi_ras.frontiera_pubblicazione_articoli	hcbi_ras.src_tmp_pubblicazione_articoli	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
9	1	hcbi_ras.v_frontiera_anag_tipo_utente	hcbi_ras.src_tmp_anag_tipo_utente	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
4	1	hcbi_ras.frontiera_anag_informatori	hcbi_ras.src_tmp_anag_informatori	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
11	1	hcbi_ras.v_frontiera_anag_tipologia	hcbi_ras.src_tmp_anag_tipologia_vw	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
8	1	hcbi_ras.frontiera_anag_utenti	hcbi_ras.src_tmp_anag_utenti	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
18	1	hcbi_ras.frontiera_prezzi_rilevati	hcbi_ras.src_tmp_prezzi_rilevati	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
17	1	hcbi_ras.frontiera_anag_ateco_2002	hcbi_ras.src_tmp_anag_ateco_2002	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
10	1	hcbi_ras.frontiera_anag_articolo	hcbi_ras.src_tmp_anag_articolo	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
14	1	hcbi_ras.frontiera_anag_unita_misura	hcbi_ras.src_tmp_anag_unita_misura	Y	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
3	1	hcbi_ras.frontiera_pubblicazione_analisi	hcbi_ras.src_tmp_pubblicazione_analisi	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
2	1	hcbi_ras.frontiera_pubblicazione_albero	hcbi_ras.src_tmp_pubblicazione_albero	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
7	1	hcbi_ras.frontiera_anni	hcbi_ras.src_tmp_anag_versione	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
19	1	hcbi_ras.frontiera_prezzi_approvati	hcbi_ras.src_tmp_prezzi_approvati	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
13	1	hcbi_ras.v_frontiera_anag_sottocapitolo	hcbi_ras.src_tmp_anag_sottocapitolo_vw	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
12	1	hcbi_ras.v_frontiera_anag_capitolo	hcbi_ras.src_tmp_anag_capitolo_vw	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
20	1	hcbi_ras.frontiera_articoli_informatori	hcbi_ras.src_tmp_articoli_informatori	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
5	1	hcbi_ras.frontiera_anag_provincia	hcbi_ras.src_tmp_anag_provincia	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
15	1	hcbi_ras.frontiera_anag_livello_codifica	hcbi_ras.src_tmp_anag_livello_codifica	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
16	1	hcbi_ras.frontiera_anag_macro_gruppo	hcbi_ras.src_tmp_anag_macro_gruppo	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
22	1	hcbi_ras.frontiera_firenze_articoli	hcbi_ras.src_tmp_firenze_articoli	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
21	1	hcbi_ras.frontiera_firenze_analisi	hcbi_ras.src_tmp_firenze_analisi	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
6	1	hcbi_ras.frontiera_anag_area_vasta	hcbi_ras.src_tmp_anag_area_vasta	N	2026-09-10 08:28:58.57576	ADMIN	2026-09-10 08:28:58.57576	ADMIN
\.


--
-- TOC entry 5610 (class 0 OID 0)
-- Dependencies: 477
-- Name: dwh_schedule_schedule_id_seq; Type: SEQUENCE SET; Schema: hcbi_utility; Owner: postgres
--

SELECT pg_catalog.setval('hcbi_utility.dwh_schedule_schedule_id_seq', 1, false);


--
-- TOC entry 5611 (class 0 OID 0)
-- Dependencies: 436
-- Name: etl_dwh_refresh_run_run_id_seq; Type: SEQUENCE SET; Schema: hcbi_utility; Owner: hcbi_utility
--

SELECT pg_catalog.setval('hcbi_utility.etl_dwh_refresh_run_run_id_seq', 1, false);


--
-- TOC entry 5612 (class 0 OID 0)
-- Dependencies: 482
-- Name: etl_execution_log_event_event_id_seq; Type: SEQUENCE SET; Schema: hcbi_utility; Owner: hcbi_utility
--

SELECT pg_catalog.setval('hcbi_utility.etl_execution_log_event_event_id_seq', 1, false);


--
-- TOC entry 5613 (class 0 OID 0)
-- Dependencies: 480
-- Name: etl_execution_log_ingestion_ingestion_id_seq; Type: SEQUENCE SET; Schema: hcbi_utility; Owner: hcbi_utility
--

SELECT pg_catalog.setval('hcbi_utility.etl_execution_log_ingestion_ingestion_id_seq', 1, false);


--
-- TOC entry 5614 (class 0 OID 0)
-- Dependencies: 433
-- Name: etl_frontiere_run_run_id_seq; Type: SEQUENCE SET; Schema: hcbi_utility; Owner: hcbi_utility
--

SELECT pg_catalog.setval('hcbi_utility.etl_frontiere_run_run_id_seq', 1, false);


--
-- TOC entry 5615 (class 0 OID 0)
-- Dependencies: 418
-- Name: seq_log_chain; Type: SEQUENCE SET; Schema: hcbi_utility; Owner: hcbi_utility
--

SELECT pg_catalog.setval('hcbi_utility.seq_log_chain', 1, false);


--
-- TOC entry 5616 (class 0 OID 0)
-- Dependencies: 420
-- Name: seq_log_step; Type: SEQUENCE SET; Schema: hcbi_utility; Owner: hcbi_utility
--

SELECT pg_catalog.setval('hcbi_utility.seq_log_step', 1, false);


--
-- TOC entry 5617 (class 0 OID 0)
-- Dependencies: 422
-- Name: seq_srv_config_step; Type: SEQUENCE SET; Schema: hcbi_utility; Owner: hcbi_utility
--

SELECT pg_catalog.setval('hcbi_utility.seq_srv_config_step', 67, false);


--
-- TOC entry 5618 (class 0 OID 0)
-- Dependencies: 423
-- Name: seq_srv_metadata_copy_src; Type: SEQUENCE SET; Schema: hcbi_utility; Owner: hcbi_utility
--

SELECT pg_catalog.setval('hcbi_utility.seq_srv_metadata_copy_src', 1, false);


--
-- TOC entry 5619 (class 0 OID 0)
-- Dependencies: 424
-- Name: seq_srv_svecchiamento_fct; Type: SEQUENCE SET; Schema: hcbi_utility; Owner: hcbi_utility
--

SELECT pg_catalog.setval('hcbi_utility.seq_srv_svecchiamento_fct', 1, false);


--
-- TOC entry 5231 (class 2606 OID 396077095)
-- Name: cfg_connections cfg_connections_pkey; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.cfg_connections
    ADD CONSTRAINT cfg_connections_pkey PRIMARY KEY (conn_name);


--
-- TOC entry 5270 (class 2606 OID 398901520)
-- Name: dwh_schedule_run dwh_schedule_run_pkey; Type: CONSTRAINT; Schema: hcbi_utility; Owner: postgres
--

ALTER TABLE ONLY hcbi_utility.dwh_schedule_run
    ADD CONSTRAINT dwh_schedule_run_pkey PRIMARY KEY (run_id);


--
-- TOC entry 5265 (class 2606 OID 398901503)
-- Name: dwh_schedule pk_dwh_schedule; Type: CONSTRAINT; Schema: hcbi_utility; Owner: postgres
--

ALTER TABLE ONLY hcbi_utility.dwh_schedule
    ADD CONSTRAINT pk_dwh_schedule PRIMARY KEY (schedule_id);


--
-- TOC entry 5263 (class 2606 OID 396127234)
-- Name: etl_dwh_refresh_run pk_etl_dwh_refresh_run; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_dwh_refresh_run
    ADD CONSTRAINT pk_etl_dwh_refresh_run PRIMARY KEY (run_id);


--
-- TOC entry 5281 (class 2606 OID 399416129)
-- Name: etl_execution_log_event pk_etl_execution_log_event; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_execution_log_event
    ADD CONSTRAINT pk_etl_execution_log_event PRIMARY KEY (event_id);


--
-- TOC entry 5276 (class 2606 OID 399416107)
-- Name: etl_execution_log_ingestion pk_etl_execution_log_ingestion; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_execution_log_ingestion
    ADD CONSTRAINT pk_etl_execution_log_ingestion PRIMARY KEY (ingestion_id);


--
-- TOC entry 5251 (class 2606 OID 396106624)
-- Name: etl_frontiere_config pk_etl_frontiere_config; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_frontiere_config
    ADD CONSTRAINT pk_etl_frontiere_config PRIMARY KEY (frontiera_code);


--
-- TOC entry 5257 (class 2606 OID 396106725)
-- Name: etl_frontiere_execution_lock pk_etl_frontiere_execution_lock; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_frontiere_execution_lock
    ADD CONSTRAINT pk_etl_frontiere_execution_lock PRIMARY KEY (frontiera_code);


--
-- TOC entry 5255 (class 2606 OID 396106711)
-- Name: etl_frontiere_run pk_etl_frontiere_run; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_frontiere_run
    ADD CONSTRAINT pk_etl_frontiere_run PRIMARY KEY (run_id);


--
-- TOC entry 5235 (class 2606 OID 396077097)
-- Name: log_chain pk_log_chain; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.log_chain
    ADD CONSTRAINT pk_log_chain PRIMARY KEY (id_log);


--
-- TOC entry 5241 (class 2606 OID 396077099)
-- Name: log_step pk_log_step; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.log_step
    ADD CONSTRAINT pk_log_step PRIMARY KEY (id_log);


--
-- TOC entry 5243 (class 2606 OID 396077101)
-- Name: srv_config_chain pk_srv_config_chain; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.srv_config_chain
    ADD CONSTRAINT pk_srv_config_chain PRIMARY KEY (id_chain);


--
-- TOC entry 5247 (class 2606 OID 396077103)
-- Name: srv_config_step pk_srv_config_step; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.srv_config_step
    ADD CONSTRAINT pk_srv_config_step PRIMARY KEY (id_step, id_chain);


--
-- TOC entry 5249 (class 2606 OID 396077105)
-- Name: srv_metadata_copy_src pk_srv_metadata_copy_src; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.srv_metadata_copy_src
    ADD CONSTRAINT pk_srv_metadata_copy_src PRIMARY KEY (id_config);


--
-- TOC entry 5245 (class 2606 OID 396077107)
-- Name: srv_config_chain uk_ds_chain_name; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.srv_config_chain
    ADD CONSTRAINT uk_ds_chain_name UNIQUE (ds_chain_name);


--
-- TOC entry 5268 (class 2606 OID 398901505)
-- Name: dwh_schedule uq_dwh_schedule_process; Type: CONSTRAINT; Schema: hcbi_utility; Owner: postgres
--

ALTER TABLE ONLY hcbi_utility.dwh_schedule
    ADD CONSTRAINT uq_dwh_schedule_process UNIQUE (process_code);


--
-- TOC entry 5283 (class 2606 OID 399416131)
-- Name: etl_execution_log_event uq_etl_execution_log_event_identity; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_execution_log_event
    ADD CONSTRAINT uq_etl_execution_log_event_identity UNIQUE (source_code, source_device, source_inode, byte_offset_start, byte_offset_end, event_hash);


--
-- TOC entry 5259 (class 2606 OID 396106727)
-- Name: etl_frontiere_execution_lock uq_etl_frontiere_execution_lock_run; Type: CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_frontiere_execution_lock
    ADD CONSTRAINT uq_etl_frontiere_execution_lock_run UNIQUE (run_id);


--
-- TOC entry 5271 (class 1259 OID 398901526)
-- Name: ix_dwh_schedule_run_schedule_started; Type: INDEX; Schema: hcbi_utility; Owner: postgres
--

CREATE INDEX ix_dwh_schedule_run_schedule_started ON hcbi_utility.dwh_schedule_run USING btree (schedule_id, started_at DESC);


--
-- TOC entry 5272 (class 1259 OID 398901527)
-- Name: ix_dwh_schedule_run_status_started; Type: INDEX; Schema: hcbi_utility; Owner: postgres
--

CREATE INDEX ix_dwh_schedule_run_status_started ON hcbi_utility.dwh_schedule_run USING btree (status, started_at DESC);


--
-- TOC entry 5260 (class 1259 OID 396127235)
-- Name: ix_etl_dwh_refresh_run_01; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_etl_dwh_refresh_run_01 ON hcbi_utility.etl_dwh_refresh_run USING btree (execution_uuid, started_at DESC);


--
-- TOC entry 5261 (class 1259 OID 396127236)
-- Name: ix_etl_dwh_refresh_run_02; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_etl_dwh_refresh_run_02 ON hcbi_utility.etl_dwh_refresh_run USING btree (status, started_at DESC);


--
-- TOC entry 5277 (class 1259 OID 399416137)
-- Name: ix_etl_execution_log_event_execution_time; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_etl_execution_log_event_execution_time ON hcbi_utility.etl_execution_log_event USING btree (event_execution_uuid, event_timestamp);


--
-- TOC entry 5278 (class 1259 OID 399416139)
-- Name: ix_etl_execution_log_event_ingestion; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_etl_execution_log_event_ingestion ON hcbi_utility.etl_execution_log_event USING btree (ingestion_id);


--
-- TOC entry 5279 (class 1259 OID 399416138)
-- Name: ix_etl_execution_log_event_scheduler_run; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_etl_execution_log_event_scheduler_run ON hcbi_utility.etl_execution_log_event USING btree (manifest_scheduler_run_id, event_timestamp);


--
-- TOC entry 5273 (class 1259 OID 399416114)
-- Name: ix_etl_execution_log_ingestion_source_started; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_etl_execution_log_ingestion_source_started ON hcbi_utility.etl_execution_log_ingestion USING btree (source_code, started_at DESC);


--
-- TOC entry 5274 (class 1259 OID 399416113)
-- Name: ix_etl_execution_log_ingestion_status_started; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_etl_execution_log_ingestion_status_started ON hcbi_utility.etl_execution_log_ingestion USING btree (status, started_at DESC);


--
-- TOC entry 5252 (class 1259 OID 396106717)
-- Name: ix_etl_frontiere_run_01; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_etl_frontiere_run_01 ON hcbi_utility.etl_frontiere_run USING btree (frontiera_code, started_at DESC) WITH (fillfactor='100', deduplicate_items='true');


--
-- TOC entry 5253 (class 1259 OID 396106718)
-- Name: ix_etl_frontiere_run_02; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_etl_frontiere_run_02 ON hcbi_utility.etl_frontiere_run USING btree (status, started_at DESC) WITH (fillfactor='100', deduplicate_items='true');


--
-- TOC entry 5232 (class 1259 OID 396077141)
-- Name: ix_log_chain_id_chain; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_log_chain_id_chain ON hcbi_utility.log_chain USING btree (id_chain);


--
-- TOC entry 5233 (class 1259 OID 396077142)
-- Name: ix_log_chain_status; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_log_chain_status ON hcbi_utility.log_chain USING btree (ds_status);


--
-- TOC entry 5236 (class 1259 OID 396077143)
-- Name: ix_log_step_chain; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_log_step_chain ON hcbi_utility.log_step USING btree (id_chain);


--
-- TOC entry 5237 (class 1259 OID 396077144)
-- Name: ix_log_step_chainlog; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_log_step_chainlog ON hcbi_utility.log_step USING btree (id_chain_log);


--
-- TOC entry 5238 (class 1259 OID 396077145)
-- Name: ix_log_step_status; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_log_step_status ON hcbi_utility.log_step USING btree (ds_status);


--
-- TOC entry 5239 (class 1259 OID 396077146)
-- Name: ix_log_step_step; Type: INDEX; Schema: hcbi_utility; Owner: hcbi_utility
--

CREATE INDEX ix_log_step_step ON hcbi_utility.log_step USING btree (id_step);


--
-- TOC entry 5266 (class 1259 OID 398901506)
-- Name: uq_dwh_schedule_one_enabled; Type: INDEX; Schema: hcbi_utility; Owner: postgres
--

CREATE UNIQUE INDEX uq_dwh_schedule_one_enabled ON hcbi_utility.dwh_schedule USING btree (enabled) WHERE enabled;


--
-- TOC entry 5294 (class 2620 OID 398901529)
-- Name: dwh_schedule trg_dwh_schedule_enable_exclusive; Type: TRIGGER; Schema: hcbi_utility; Owner: postgres
--

CREATE TRIGGER trg_dwh_schedule_enable_exclusive BEFORE INSERT OR UPDATE ON hcbi_utility.dwh_schedule FOR EACH ROW EXECUTE FUNCTION hcbi_utility.fn_dwh_schedule_enable_exclusive();


--
-- TOC entry 5291 (class 2606 OID 398901521)
-- Name: dwh_schedule_run dwh_schedule_run_schedule_id_fkey; Type: FK CONSTRAINT; Schema: hcbi_utility; Owner: postgres
--

ALTER TABLE ONLY hcbi_utility.dwh_schedule_run
    ADD CONSTRAINT dwh_schedule_run_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES hcbi_utility.dwh_schedule(schedule_id);


--
-- TOC entry 5293 (class 2606 OID 399416132)
-- Name: etl_execution_log_event fk_etl_execution_log_event_ingestion; Type: FK CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_execution_log_event
    ADD CONSTRAINT fk_etl_execution_log_event_ingestion FOREIGN KEY (ingestion_id) REFERENCES hcbi_utility.etl_execution_log_ingestion(ingestion_id);


--
-- TOC entry 5292 (class 2606 OID 399416108)
-- Name: etl_execution_log_ingestion fk_etl_execution_log_ingestion_retry; Type: FK CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_execution_log_ingestion
    ADD CONSTRAINT fk_etl_execution_log_ingestion_retry FOREIGN KEY (retry_of_ingestion_id) REFERENCES hcbi_utility.etl_execution_log_ingestion(ingestion_id);


--
-- TOC entry 5289 (class 2606 OID 396106728)
-- Name: etl_frontiere_execution_lock fk_etl_frontiere_execution_lock_config; Type: FK CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_frontiere_execution_lock
    ADD CONSTRAINT fk_etl_frontiere_execution_lock_config FOREIGN KEY (frontiera_code) REFERENCES hcbi_utility.etl_frontiere_config(frontiera_code);


--
-- TOC entry 5290 (class 2606 OID 396106733)
-- Name: etl_frontiere_execution_lock fk_etl_frontiere_execution_lock_run; Type: FK CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_frontiere_execution_lock
    ADD CONSTRAINT fk_etl_frontiere_execution_lock_run FOREIGN KEY (run_id) REFERENCES hcbi_utility.etl_frontiere_run(run_id) ON DELETE CASCADE;


--
-- TOC entry 5288 (class 2606 OID 396106712)
-- Name: etl_frontiere_run fk_etl_frontiere_run_config; Type: FK CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.etl_frontiere_run
    ADD CONSTRAINT fk_etl_frontiere_run_config FOREIGN KEY (frontiera_code) REFERENCES hcbi_utility.etl_frontiere_config(frontiera_code);


--
-- TOC entry 5284 (class 2606 OID 396077417)
-- Name: log_chain fk_log_chain_id_chain; Type: FK CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.log_chain
    ADD CONSTRAINT fk_log_chain_id_chain FOREIGN KEY (id_chain) REFERENCES hcbi_utility.srv_config_chain(id_chain);


--
-- TOC entry 5285 (class 2606 OID 396077422)
-- Name: log_step fk_log_step_id_chain_id_step; Type: FK CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.log_step
    ADD CONSTRAINT fk_log_step_id_chain_id_step FOREIGN KEY (id_step, id_chain) REFERENCES hcbi_utility.srv_config_step(id_step, id_chain);


--
-- TOC entry 5286 (class 2606 OID 396077427)
-- Name: srv_config_step fk_srv_config_step_id_chain; Type: FK CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.srv_config_step
    ADD CONSTRAINT fk_srv_config_step_id_chain FOREIGN KEY (id_chain) REFERENCES hcbi_utility.srv_config_chain(id_chain);


--
-- TOC entry 5287 (class 2606 OID 396077432)
-- Name: srv_metadata_copy_src fk_srv_metadata_copy_src_id_chain; Type: FK CONSTRAINT; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER TABLE ONLY hcbi_utility.srv_metadata_copy_src
    ADD CONSTRAINT fk_srv_metadata_copy_src_id_chain FOREIGN KEY (id_chain) REFERENCES hcbi_utility.srv_config_chain(id_chain);


--
-- TOC entry 5536 (class 0 OID 0)
-- Dependencies: 12
-- Name: SCHEMA hcbi_utility; Type: ACL; Schema: -; Owner: hcbi_utility
--

GRANT USAGE ON SCHEMA hcbi_utility TO hcbi_ras;


--
-- TOC entry 5537 (class 0 OID 0)
-- Dependencies: 694
-- Name: FUNCTION disconnect_dblink_logging(); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON FUNCTION hcbi_utility.disconnect_dblink_logging() TO hcbi_ras;


--
-- TOC entry 5539 (class 0 OID 0)
-- Dependencies: 633
-- Name: FUNCTION ensure_dblink_logging(); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

REVOKE ALL ON FUNCTION hcbi_utility.ensure_dblink_logging() FROM PUBLIC;
GRANT ALL ON FUNCTION hcbi_utility.ensure_dblink_logging() TO hcbi_ras;


--
-- TOC entry 5540 (class 0 OID 0)
-- Dependencies: 521
-- Name: FUNCTION fn_dwh_schedule_enable_exclusive(); Type: ACL; Schema: hcbi_utility; Owner: postgres
--

GRANT ALL ON FUNCTION hcbi_utility.fn_dwh_schedule_enable_exclusive() TO hcbi_ras;


--
-- TOC entry 5541 (class 0 OID 0)
-- Dependencies: 486
-- Name: FUNCTION get_conn_string(p_conn_name character varying); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON FUNCTION hcbi_utility.get_conn_string(p_conn_name character varying) TO hcbi_ras;


--
-- TOC entry 5543 (class 0 OID 0)
-- Dependencies: 771
-- Name: FUNCTION get_current_etl_execution_uuid(); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON FUNCTION hcbi_utility.get_current_etl_execution_uuid() TO hcbi_ras;


--
-- TOC entry 5544 (class 0 OID 0)
-- Dependencies: 561
-- Name: PROCEDURE init_dblink_logging(); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON PROCEDURE hcbi_utility.init_dblink_logging() TO hcbi_ras;


--
-- TOC entry 5545 (class 0 OID 0)
-- Dependencies: 665
-- Name: FUNCTION pkg_log_display_backtrace_fnc(p_context text); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON FUNCTION hcbi_utility.pkg_log_display_backtrace_fnc(p_context text) TO hcbi_ras;


--
-- TOC entry 5546 (class 0 OID 0)
-- Dependencies: 522
-- Name: FUNCTION pkg_log_display_error_stack_fnc(p_sqlstate text, p_message text, p_detail text, p_hint text); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON FUNCTION hcbi_utility.pkg_log_display_error_stack_fnc(p_sqlstate text, p_message text, p_detail text, p_hint text) TO hcbi_ras;


--
-- TOC entry 5547 (class 0 OID 0)
-- Dependencies: 707
-- Name: FUNCTION pkg_log_fnc_insert_log(p_id_chain_log bigint, p_id_chain bigint, p_id_step bigint, p_ds_step_name text, p_dt_start timestamp without time zone, p_dt_creation timestamp without time zone, p_ds_transaction text); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON FUNCTION hcbi_utility.pkg_log_fnc_insert_log(p_id_chain_log bigint, p_id_chain bigint, p_id_step bigint, p_ds_step_name text, p_dt_start timestamp without time zone, p_dt_creation timestamp without time zone, p_ds_transaction text) TO hcbi_ras;


--
-- TOC entry 5548 (class 0 OID 0)
-- Dependencies: 505
-- Name: PROCEDURE pkg_log_prc_error_update_log(IN p_id_log bigint, IN p_ds_status text, IN p_ds_error text, IN p_dt_update timestamp without time zone, IN p_ds_transaction text); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON PROCEDURE hcbi_utility.pkg_log_prc_error_update_log(IN p_id_log bigint, IN p_ds_status text, IN p_ds_error text, IN p_dt_update timestamp without time zone, IN p_ds_transaction text) TO hcbi_ras;


--
-- TOC entry 5549 (class 0 OID 0)
-- Dependencies: 573
-- Name: PROCEDURE pkg_log_prc_update_log(IN p_id_log bigint, IN p_nr_selected bigint, IN p_nr_inserted bigint, IN p_nr_updated bigint, IN p_nr_deleted bigint, IN p_nr_rec_errors bigint, IN p_ds_status text, IN p_dt_update timestamp without time zone, IN p_ds_transaction text); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON PROCEDURE hcbi_utility.pkg_log_prc_update_log(IN p_id_log bigint, IN p_nr_selected bigint, IN p_nr_inserted bigint, IN p_nr_updated bigint, IN p_nr_deleted bigint, IN p_nr_rec_errors bigint, IN p_ds_status text, IN p_dt_update timestamp without time zone, IN p_ds_transaction text) TO hcbi_ras;


--
-- TOC entry 5550 (class 0 OID 0)
-- Dependencies: 735
-- Name: PROCEDURE prc_end_chain(IN p_id_log bigint, IN p_ds_status text, IN p_error_msg text); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON PROCEDURE hcbi_utility.prc_end_chain(IN p_id_log bigint, IN p_ds_status text, IN p_error_msg text) TO hcbi_ras;


--
-- TOC entry 5551 (class 0 OID 0)
-- Dependencies: 575
-- Name: PROCEDURE prc_execute_chain(IN p_id_chain bigint); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON PROCEDURE hcbi_utility.prc_execute_chain(IN p_id_chain bigint) TO hcbi_ras;


--
-- TOC entry 5552 (class 0 OID 0)
-- Dependencies: 693
-- Name: PROCEDURE prc_grant_to_hcbi_ras(); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON PROCEDURE hcbi_utility.prc_grant_to_hcbi_ras() TO hcbi_ras;


--
-- TOC entry 5553 (class 0 OID 0)
-- Dependencies: 556
-- Name: PROCEDURE prc_mark_chain_failed(IN p_id_log bigint, IN p_error_msg text); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON PROCEDURE hcbi_utility.prc_mark_chain_failed(IN p_id_log bigint, IN p_error_msg text) TO hcbi_ras;


--
-- TOC entry 5554 (class 0 OID 0)
-- Dependencies: 488
-- Name: PROCEDURE prc_start_chain(IN p_id_chain bigint, OUT p_id_log bigint); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON PROCEDURE hcbi_utility.prc_start_chain(IN p_id_chain bigint, OUT p_id_log bigint) TO hcbi_ras;


--
-- TOC entry 5555 (class 0 OID 0)
-- Dependencies: 721
-- Name: PROCEDURE test_p(IN p_id integer, INOUT p_result integer); Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON PROCEDURE hcbi_utility.test_p(IN p_id integer, INOUT p_result integer) TO hcbi_ras;


--
-- TOC entry 5556 (class 0 OID 0)
-- Dependencies: 417
-- Name: TABLE cfg_connections; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.cfg_connections TO hcbi_ras;


--
-- TOC entry 5557 (class 0 OID 0)
-- Dependencies: 478
-- Name: TABLE dwh_schedule; Type: ACL; Schema: hcbi_utility; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE hcbi_utility.dwh_schedule TO hcbi_ras;


--
-- TOC entry 5558 (class 0 OID 0)
-- Dependencies: 479
-- Name: TABLE dwh_schedule_run; Type: ACL; Schema: hcbi_utility; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE hcbi_utility.dwh_schedule_run TO hcbi_ras;


--
-- TOC entry 5559 (class 0 OID 0)
-- Dependencies: 477
-- Name: SEQUENCE dwh_schedule_schedule_id_seq; Type: ACL; Schema: hcbi_utility; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE hcbi_utility.dwh_schedule_schedule_id_seq TO hcbi_ras;


--
-- TOC entry 5561 (class 0 OID 0)
-- Dependencies: 437
-- Name: TABLE etl_dwh_refresh_run; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.etl_dwh_refresh_run TO hcbi_ras;


--
-- TOC entry 5562 (class 0 OID 0)
-- Dependencies: 436
-- Name: SEQUENCE etl_dwh_refresh_run_run_id_seq; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON SEQUENCE hcbi_utility.etl_dwh_refresh_run_run_id_seq TO hcbi_ras;


--
-- TOC entry 5565 (class 0 OID 0)
-- Dependencies: 483
-- Name: TABLE etl_execution_log_event; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT ON TABLE hcbi_utility.etl_execution_log_event TO hcbi_ras;


--
-- TOC entry 5566 (class 0 OID 0)
-- Dependencies: 482
-- Name: SEQUENCE etl_execution_log_event_event_id_seq; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,USAGE ON SEQUENCE hcbi_utility.etl_execution_log_event_event_id_seq TO hcbi_ras;


--
-- TOC entry 5568 (class 0 OID 0)
-- Dependencies: 481
-- Name: TABLE etl_execution_log_ingestion; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,UPDATE ON TABLE hcbi_utility.etl_execution_log_ingestion TO hcbi_ras;


--
-- TOC entry 5569 (class 0 OID 0)
-- Dependencies: 480
-- Name: SEQUENCE etl_execution_log_ingestion_ingestion_id_seq; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,USAGE ON SEQUENCE hcbi_utility.etl_execution_log_ingestion_ingestion_id_seq TO hcbi_ras;


--
-- TOC entry 5573 (class 0 OID 0)
-- Dependencies: 430
-- Name: TABLE etl_frontiere_config; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.etl_frontiere_config TO hcbi_ras;


--
-- TOC entry 5575 (class 0 OID 0)
-- Dependencies: 435
-- Name: TABLE etl_frontiere_execution_lock; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.etl_frontiere_execution_lock TO hcbi_ras;


--
-- TOC entry 5577 (class 0 OID 0)
-- Dependencies: 434
-- Name: TABLE etl_frontiere_run; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.etl_frontiere_run TO hcbi_ras;


--
-- TOC entry 5578 (class 0 OID 0)
-- Dependencies: 433
-- Name: SEQUENCE etl_frontiere_run_run_id_seq; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON SEQUENCE hcbi_utility.etl_frontiere_run_run_id_seq TO hcbi_ras;


--
-- TOC entry 5579 (class 0 OID 0)
-- Dependencies: 418
-- Name: SEQUENCE seq_log_chain; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON SEQUENCE hcbi_utility.seq_log_chain TO hcbi_ras;


--
-- TOC entry 5581 (class 0 OID 0)
-- Dependencies: 419
-- Name: TABLE log_chain; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.log_chain TO hcbi_ras;


--
-- TOC entry 5582 (class 0 OID 0)
-- Dependencies: 420
-- Name: SEQUENCE seq_log_step; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON SEQUENCE hcbi_utility.seq_log_step TO hcbi_ras;


--
-- TOC entry 5584 (class 0 OID 0)
-- Dependencies: 421
-- Name: TABLE log_step; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.log_step TO hcbi_ras;


--
-- TOC entry 5585 (class 0 OID 0)
-- Dependencies: 422
-- Name: SEQUENCE seq_srv_config_step; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON SEQUENCE hcbi_utility.seq_srv_config_step TO hcbi_ras;


--
-- TOC entry 5586 (class 0 OID 0)
-- Dependencies: 423
-- Name: SEQUENCE seq_srv_metadata_copy_src; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON SEQUENCE hcbi_utility.seq_srv_metadata_copy_src TO hcbi_ras;


--
-- TOC entry 5587 (class 0 OID 0)
-- Dependencies: 424
-- Name: SEQUENCE seq_srv_svecchiamento_fct; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT ALL ON SEQUENCE hcbi_utility.seq_srv_svecchiamento_fct TO hcbi_ras;


--
-- TOC entry 5592 (class 0 OID 0)
-- Dependencies: 425
-- Name: TABLE srv_config_chain; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.srv_config_chain TO hcbi_ras;


--
-- TOC entry 5594 (class 0 OID 0)
-- Dependencies: 426
-- Name: TABLE srv_config_step; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.srv_config_step TO hcbi_ras;


--
-- TOC entry 5605 (class 0 OID 0)
-- Dependencies: 427
-- Name: TABLE srv_metadata_copy_src; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.srv_metadata_copy_src TO hcbi_ras;


--
-- TOC entry 5606 (class 0 OID 0)
-- Dependencies: 428
-- Name: TABLE v_check_step_da_ottimizzare; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.v_check_step_da_ottimizzare TO hcbi_ras;


--
-- TOC entry 5607 (class 0 OID 0)
-- Dependencies: 429
-- Name: TABLE v_log_chain_last_run; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.v_log_chain_last_run TO hcbi_ras;


--
-- TOC entry 5609 (class 0 OID 0)
-- Dependencies: 431
-- Name: TABLE vw_etl_frontiere_config; Type: ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLE hcbi_utility.vw_etl_frontiere_config TO hcbi_ras;


--
-- TOC entry 3055 (class 826 OID 396106673)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER DEFAULT PRIVILEGES FOR ROLE hcbi_utility IN SCHEMA hcbi_utility GRANT ALL ON SEQUENCES TO hcbi_utility;
ALTER DEFAULT PRIVILEGES FOR ROLE hcbi_utility IN SCHEMA hcbi_utility GRANT ALL ON SEQUENCES TO hcbi_ras;


--
-- TOC entry 3053 (class 826 OID 396106674)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER DEFAULT PRIVILEGES FOR ROLE hcbi_utility IN SCHEMA hcbi_utility GRANT ALL ON FUNCTIONS TO hcbi_utility;
ALTER DEFAULT PRIVILEGES FOR ROLE hcbi_utility IN SCHEMA hcbi_utility GRANT ALL ON FUNCTIONS TO hcbi_ras;


--
-- TOC entry 3054 (class 826 OID 396106672)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: hcbi_utility; Owner: hcbi_utility
--

ALTER DEFAULT PRIVILEGES FOR ROLE hcbi_utility IN SCHEMA hcbi_utility GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO hcbi_utility;
ALTER DEFAULT PRIVILEGES FOR ROLE hcbi_utility IN SCHEMA hcbi_utility GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,UPDATE ON TABLES TO hcbi_ras;


-- Completed on 2026-11-05 22:58:56

--
-- PostgreSQL database dump complete
--

\unrestrict XXaPjGenISI46sq0eEtFEvmQ2YRky78goHBmCSdcoGv0ON0udcpdwkxhpDaqdTv

